import { Component, OnInit,Input,Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';
@Injectable({
providedIn: 'root'
})
export class Max_Qualification_Service {

constructor(private http: HttpClient)
       {
              const httpOptions = {
              headers: new HttpHeaders({
              'Content-Type':  'application/json'
       })
       };
       }      

AnimationKeyframesSequenceMetadata



Save_Max_Qualification(Max_Qualification_)
{
       return this.http.post(environment.BasePath +'Max_Qualification/Save_Max_Qualification/',Max_Qualification_);
}





private extractData(res: Response)
       {
         let body = res;
         return body || { };
       }


 Search_Max_Qualification(Max_Qualification_Name):Observable<any>
       {
              var Search_Data={'Max_Qualification_Name':Max_Qualification_Name}
              return this.http.get(environment.BasePath +'Max_Qualification/Search_Max_Qualification/',{params:Search_Data});
       }



       Search_Max_Qualification_Typeahead(Max_Qualification_Name,Level_Id):Observable<any>
       {
             debugger
             var Search_Data={'Max_Qualification_Name':Max_Qualification_Name,'Level_Id':Level_Id}
             return this.http.get(environment.BasePath +'Max_Qualification/Search_Max_Qualification_Typeahead/',{params:Search_Data});
       }
      
      
       Search_Job_Qualification_Typeahead(Max_Qualification_Name):Observable<any>
       {
             debugger
             var Search_Data={'Max_Qualification_Name':Max_Qualification_Name}
             return this.http.get(environment.BasePath +'Max_Qualification/Search_Job_Qualification_Typeahead/',{params:Search_Data});
       }

 Search_Job_Typeahead(Job_Name,Job_Category_Id):Observable<any>
 {
       debugger
       var Search_Data={'Job_Name':Job_Name,'Job_Category_Id':Job_Category_Id}
       return this.http.get(environment.BasePath +'Max_Qualification/Search_Job_Typeahead_New/',{params:Search_Data});
 }


 Search_Job_Typeahead_Temp(Job_Name):Observable<any>
 {
       debugger
       var Search_Data={'Job_Name':Job_Name}
       return this.http.get(environment.BasePath +'Max_Qualification/Search_Job_Typeahead_Temp/',{params:Search_Data});
 }

 Delete_Max_Qualification(Max_Qualification_Id)
 {
       return this.http.get(environment.BasePath +'Max_Qualification/Delete_Max_Qualification/'+Max_Qualification_Id);
 }




 Get_Menu_Status(Menu_Id_,Login_User_)
 {
        return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);             
 }              

}
