import { Component, OnInit,Input,Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';
@Injectable({
providedIn: 'root'
})
export class Agent_Data_Service {
constructor(private http: HttpClient)
{
const httpOptions = {
headers: new HttpHeaders({
'Content-Type':  'application/json'
})
};
}AnimationKeyframesSequenceMetadata
Save_Agent_Data(Agent_Data_)
{
    debugger 
return this.http.post(environment.BasePath +'Agent_Data/Save_Agent_Data/',Agent_Data_);}
private extractData(res: Response)
{
let body = res;
return body || { };
}
Search_Agent_Data(Name_):Observable<any>
{
    debugger
 return this.http.get(environment.BasePath +'Agent_Data/Search_Agent_Data/'+Name_);}


 
 Search_Agent_Data_Typeahead(Agent_Name):Observable<any>
 {
  return this.http.get(environment.BasePath +'Agent_Data/Search_Agent_Data_Typeahead/'+Agent_Name);}

 Load_Agent_Data(Agent_Name):Observable<any>
 {
  return this.http.get(environment.BasePath +'Agent_Data/Load_Agent_Data/'+Agent_Name);}

 Delete_Agent_Data(Agent_Id_)
{
    debugger
 return this.http.get(environment.BasePath +'Agent_Data/Delete_Agent_Data/'+Agent_Id_);}
Get_Agent_Data(Agent_Id_)
{
 return this.http.get(environment.BasePath +'Agent_Data/Get_Agent_Data/'+Agent_Id_);}

 Get_Menu_Status(Menu_Id_,Login_User_)
 {
        return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);
}

}

