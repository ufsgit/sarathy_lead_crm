import { Component, OnInit,Input,Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';
@Injectable({
providedIn: 'root'
})
export class Level_Service {

constructor(private http: HttpClient)
       {
              const httpOptions = {
              headers: new HttpHeaders({
              'Content-Type':  'application/json'
       })
       };
       }      

AnimationKeyframesSequenceMetadata



Save_Level(Level_)
{
       return this.http.post(environment.BasePath +'Level/Save_Level/',Level_);
}





private extractData(res: Response)
       {
         let body = res;
         return body || { };
       }


 Search_Level(Level_Name):Observable<any>
       {
              var Search_Data={'Level_Name':Level_Name}
              return this.http.get(environment.BasePath +'Level/Search_Level/',{params:Search_Data});
       }



 Search_Level_Typeahead(Level_Name):Observable<any>
 {
       var Search_Data={'Level_Name':Level_Name}
       return this.http.get(environment.BasePath +'Level/Search_Level/',{params:Search_Data});
 }

 Search_Language_Proficiency_Typeahead(Language_Proficiency_Name):Observable<any>
 {
       var Search_Data={'Language_Proficiency_Name':Language_Proficiency_Name}
       return this.http.get(environment.BasePath +'Level/Search_Language_Proficiency_Typeahead/',{params:Search_Data});
 }

 Delete_Level(Level_Id)
 {
       return this.http.get(environment.BasePath +'Level/Delete_Level/'+Level_Id);
 }




 Get_Menu_Status(Menu_Id_,Login_User_)
 {
        return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);             
 }              

}
