import { Component, OnInit,Input,Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';
@Injectable({
providedIn: 'root'
})
export class Job_Category_Service {

constructor(private http: HttpClient)
       {
              const httpOptions = {
              headers: new HttpHeaders({
              'Content-Type':  'application/json'
       })
       };
       }      

AnimationKeyframesSequenceMetadata



Save_Job_Category(Job_Category_)
{
       return this.http.post(environment.BasePath +'Job_Category/Save_Job_Category/',Job_Category_);
}





private extractData(res: Response)
       {
         let body = res;
         return body || { };
       }


 Search_Job_Category(Job_Category_Name):Observable<any>
       {
              var Search_Data={'Job_Category_Name':Job_Category_Name}
              return this.http.get(environment.BasePath +'Job_Category/Search_Job_Category/',{params:Search_Data});
       }



 Search_Job_Category_Typeahead(Job_Category_Name):Observable<any>
 {
       var Search_Data={'Job_Category_Name':Job_Category_Name}
       return this.http.get(environment.BasePath +'Job_Category/Search_Job_Category/',{params:Search_Data});
 }

 Search_Language_Proficiency_Typeahead(Language_Proficiency_Name):Observable<any>
 {
       var Search_Data={'Language_Proficiency_Name':Language_Proficiency_Name}
       return this.http.get(environment.BasePath +'Job_Category/Search_Language_Proficiency_Typeahead/',{params:Search_Data});
 }

 Delete_Job_Category(Job_Category_Id)
 {
       return this.http.get(environment.BasePath +'Job_Category/Delete_Job_Category/'+Job_Category_Id);
 }




 Get_Menu_Status(Menu_Id_,Login_User_)
 {
        return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);             
 }              

}
