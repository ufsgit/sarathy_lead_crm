import { Injectable } from "@angular/core";
import { AuthenticationService } from "./Authenticatiuon.Service";
// import {NavbarComponent} from "../components/navbar/navbar.component";

@Injectable({
	providedIn: "root",
})
export class UserData {
	_favorites: string[] = [];
	HAS_LOGGED_IN = "hasLoggedIn";
	HAS_SEEN_TUTORIAL = "hasSeenTutorial";
	Login_Id:string="0";
	pswd:string
	menuItems:any[];
	menuindex:any[];
	uname:string;
	user:string;
	loginDatanew:any

	constructor(public auth: AuthenticationService) {

		this.loginDatanew = {
			username: localStorage.getItem('uname'),  // Replace with the actual username
			password: localStorage.getItem('password')
			
			
// Replace with the actual password
		  };
		
	}
	afterLogin = (httpData) => {
		debugger;
		if (httpData.status === "error") {
			return httpData.message;
		} else if (httpData[0].length > 0) {
			var id = httpData[0];
			localStorage.setItem("Access_Token", httpData.token);
			localStorage.setItem("Login_User", id[0].User_Details_Id);
			localStorage.setItem("uname", id[0].User_Details_Name);
			localStorage.setItem("pswd", id[0].Password);
			localStorage.setItem("User_Type", id[0].User_Type);
			localStorage.setItem("Branch", id[0].Branch_Id);
			localStorage.setItem("Login_Department", id[0].Department_Id);
			localStorage.setItem("Notification_Count", id[0].Notification_Count);
			localStorage.setItem("Extension", id[0].Extension);
			localStorage.setItem("Login_Department_Name", id[0].Department_Name);
			localStorage.setItem("Updated_Serial_Id", id[0].Updated_Serial_Id);
			localStorage.setItem("Round_Robin_Status", id[0].Round_Robin_Status);
			this.setToken(httpData.access_token);
			debugger;
			return true;
		} else {
			return httpData.message;
		}
	};
	login(loginData): Promise<any> {
		debugger;
		return this.auth.Login(loginData).then(this.afterLogin);
	}
	isLoggedIn(): boolean {
		return localStorage.getItem("Access_Token") ? true : false;
	}

	afterLogout(){
		this.Login_Id=localStorage.getItem('Login_User');
		this.uname=localStorage.getItem('uname');
		this.pswd=localStorage.getItem('password');


	
	}

	// signup(signupData): Promise<any> {
	//   // return this.storage.set(this.HAS_LOGGED_IN, true).then(() => {
	//   //   this.setUsername(username);
	//   //   return this.events.publish('user:signup');
	//   // });
	//   return this.auth.signup(signupData).then(httpData => {
	//     return httpData;
	//   });
	// }

	logout() {
		debugger
		this.Login_Id=localStorage.getItem('Login_User');
		this.uname=localStorage.getItem('uname');
		this.pswd=localStorage.getItem('pswd');
		debugger
		localStorage.clear();
		return this.auth.Logout(this.uname,this.pswd).then(this.afterLogin);

	}

	User_Logged_In(uid){
		debugger
		return  this.auth.User_Logged_In(uid)
	}
	setToken(username: string) {
		return localStorage.setItem("token", username);
	}
	getToken(): Promise<any> {
		return localStorage.get("token");
	}
}
