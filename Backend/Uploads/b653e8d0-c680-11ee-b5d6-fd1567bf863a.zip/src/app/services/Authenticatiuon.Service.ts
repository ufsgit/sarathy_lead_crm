import { Injectable } from '@angular/core';
import { BaseApi } from './_BaseApi.Service';
import { LoginInterface } from '../interfaces/Genereic-Interface';

@Injectable({
    providedIn: 'root'
})
export class AuthenticationService {
    constructor(private http: BaseApi) {
    }
    Login(userData: LoginInterface): Promise<any> {

        return this.http.get('Login/Login_Check/' + userData.userName  +'/' + userData.password);
       // return this.http.get('Login/Login_Check/', +userData.userName +'/' + userData.password);
    }

    Logout(uname,pswd): Promise<any> {
        debugger
        return this.http.get('Login/Logout/' + uname  +'/' + pswd);
               // return this.http.get('Login/Login_Check/', +userData.userName +'/' + userData.password);
            }

    User_Logged_In(uid): Promise<any> {
        debugger
        return this.http.get('Login/User_Logged_In/' + uid);
    }
}
