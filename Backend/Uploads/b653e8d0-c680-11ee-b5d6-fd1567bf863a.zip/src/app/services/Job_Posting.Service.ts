import { Component, OnInit, Input, Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class Job_Posting_Service {
    constructor(private http: HttpClient) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        };
    } AnimationKeyframesSequenceMetadata
    Save_Job_Posting(Job_Posting_) {
        debugger
        return this.http.post(environment.BasePath + 'Job_Posting/Save_Job_Posting/', Job_Posting_);
    }
    private extractData(res: Response) {
        let body = res;
        return body || {};
    }
    
    Search_Job_Posting(Search_FromDate,Search_ToDate,look_In_Date_Value,Job_Id_,Job_Name_,Usersearch_,Employer_Id_): Observable<any> 
    {
        
        return this.http.get(environment.BasePath + 'Job_Posting/Search_Job_Posting/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value+'/'+Job_Id_+'/'+Job_Name_+'/'+Usersearch_+'/'+Employer_Id_);
    }



//     Search_Job_Posting_Student(Search_FromDate,Search_ToDate,look_In_Date_Value,Job_Id_,Job_Name_,Usersearch_,Employer_Id_) {
// debugger
//         var Search_Data = {
//             Search_FromDate: Search_FromDate,
//             Search_ToDate: Search_ToDate,
//             look_In_Date_Value: look_In_Date_Value,
//             Job_Id_:Job_Id_,
//             Job_Name_:Job_Name_,
//             Usersearch_:Usersearch_,
//             Employer_Id_:Employer_Id_,
//         };
//         return this.http.get(
//             environment.BasePath + "Student/Search_Job_Posting/",
//             { params: Search_Data }
//         );

//     }
    




    Search_Job_Posting_Report(Search_FromDate,Search_ToDate,look_In_Date_Value): Observable<any> {
        
        return this.http.get(environment.BasePath + 'Job_Posting/Search_Job_Posting_Report/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value);
    }

    Search_Visa_Report(Search_FromDate,Search_ToDate,look_In_Date_Value,visa_status): Observable<any> {
        
        return this.http.get(environment.BasePath + 'Job_Posting/Search_Visa_Report/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value+'/'+visa_status);
    }

    
    Search_Interview_Outcome_Report(Search_FromDate,Search_ToDate,look_In_Date_Value,Interview_Outcome_Id_): Observable<any> {
        
        return this.http.get(environment.BasePath + 'Job_Posting/Search_Interview_Outcome_Report/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value+'/'+Interview_Outcome_Id_);
    }
    
    Delete_Job_Posting(Job_Posting_Id) {
        return this.http.get(environment.BasePath + 'Job_Posting/Delete_Job_Posting/' + Job_Posting_Id);
    }
    Get_Job_Posting(Job_Posting_Id) {
        return this.http.get(environment.BasePath + 'Job_Posting/Get_Job_Posting/' + Job_Posting_Id);
    }

    Get_Menu_Status(Menu_Id_,Login_User_)
    {
           return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);
   }
   
   Get_Sub_Status(Job_Posting_Id)
   {
    return this.http.get(environment.BasePath +'Job_Posting/Get_Sub_Status/'+Job_Posting_Id);
   }


Save_Sub_Status(Sub_Status_)
{
    
return this.http.post(environment.BasePath +'Job_Posting/Save_Sub_Status/',Sub_Status_);
}

Delete_Sub_Status(Sub_Status_Id)
{
 return this.http.get(environment.BasePath +'Job_Posting/Delete_Sub_Status/'+Sub_Status_Id);
}

Load_StatusType(): Observable<any>
{
    return this.http.get(environment.BasePath + 'Department/Load_StatusType/');
}

Search_Student_Job_Report(Search_FromDate,Search_ToDate,look_In_Date_Value,Usersearch_,Job_Id_,Interest_Status_,Interview_Status_): Observable<any> {
    debugger
    return this.http.get(environment.BasePath + 'Job_Posting/Search_Student_Job_Report/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value+'/'+Usersearch_+'/'+Job_Id_+'/'+Interest_Status_+'/'+Interview_Status_);
}
Search_Interested_Candidate_List(Search_FromDate,Search_ToDate,look_In_Date_Value,Usersearch_,Job_Id_,Interest_Status_,StudentName_): Observable<any> {
    debugger
    return this.http.get(environment.BasePath + 'Job_Posting/Search_Interested_Candidate_List/' + Search_FromDate+'/'+Search_ToDate+'/'+look_In_Date_Value+'/'+Usersearch_+'/'+Job_Id_+'/'+Interest_Status_+'/'+StudentName_);
}


Save_Employer(Employer_) {
    debugger
    return this.http.post(environment.BasePath + 'Job_Posting/Save_Employer/', Employer_);
}


    Search_Employer(Employer_Name): Observable<any> {
        debugger
        var Search_Data={
            Employer_Name_:Employer_Name
          
        }
        return this.http.get(environment.BasePath + 'Job_Posting/Search_Employer/' ,{params:Search_Data});
    }




    Delete_Employer(Employer_Id) {
        debugger
        return this.http.get(environment.BasePath + 'Job_Posting/Delete_Employer/' + Employer_Id);
    }



}

