import { Component, OnInit,Input,Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AnimationKeyframesSequenceMetadata } from '@angular/animations';
@Injectable({
providedIn: 'root'
})
export class Job_Service {

constructor(private http: HttpClient)
       {
              const httpOptions = {
              headers: new HttpHeaders({
              'Content-Type':  'application/json'
       })
       };
       }      

AnimationKeyframesSequenceMetadata



Save_Job(Job_)
{
       return this.http.post(environment.BasePath +'Job/Save_Job/',Job_);
}





private extractData(res: Response)
       {
         let body = res;
         return body || { };
       }


 Search_Job(Job_Name):Observable<any>
       {
              var Search_Data={'Job_Name':Job_Name}
              return this.http.get(environment.BasePath +'Job/Search_Job/',{params:Search_Data});
       }



 Search_Job_Typeahead(Job_Name,Job_Category_Id):Observable<any>
 {
       debugger
       var Search_Data={'Job_Name':Job_Name,'Job_Category_Id':Job_Category_Id}
       return this.http.get(environment.BasePath +'Job/Search_Job_Typeahead/',{params:Search_Data});
 }

 Delete_Job(Job_Id)
 {
       return this.http.get(environment.BasePath +'Job/Delete_Job/'+Job_Id);
 }




 Get_Menu_Status(Menu_Id_,Login_User_)
 {
        return this.http.get(environment.BasePath + 'Student/Get_Menu_Status/' + Menu_Id_+'/'+Login_User_);             
 }              

}
