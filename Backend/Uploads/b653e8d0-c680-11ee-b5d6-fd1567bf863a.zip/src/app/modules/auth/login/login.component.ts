import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from '../../../helpers/custom-validators';
import { UserData } from '../../../services/user-data';
import { Route, Router } from '@angular/router';
import { MatSpinner } from '@angular/material';
import { ROUTES,Get_Page_Permission,Set_Page_Permission } from '../../../components/sidebar/sidebar.component'
import { DialogBox_Component } from '../../../modules/admin/DialogBox/DialogBox.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogConfig} from '@angular/material';
import { Menu_Service } from '../../../services/Menu.Service';
import { Student_Service } from "../../../services/Student.Service";
import { HttpClient } from '@angular/common/http';
export var Pointer_Table: number[] = [
]

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  Login_Id:string;
  // menuItems: any[];
  color = 'primary';
  mode = 'indeterminate';
  value = 200;
  issLoading: boolean;
  Notification_count:number;
  Pointer_Table=new Array(200);  
  Permissions:any
  Enrolled_Application_Only_Permission:any
  latitude: number = 0; // Initialize with a default value
  	longitude: number = 0; // Initialize with a default value
  	city: string = '';
  	suburb: string = '';
  	county: string= '';
  	country: string ='';
  	state_district ='';
  	postcode='';
  	country_code='';
  	error: string = '';
    lat: string = '';
    long: string = '';
    uid:number;

  constructor(
    public fb: FormBuilder, public Menu_Service_: Menu_Service, public userService: UserData, public router: Router,public dialogBox: MatDialog,
    private http: HttpClient,
    public Student_Service_: Student_Service
  ) {
    this.initForm();
  }
  initForm() {
    this.loginForm = this.fb.group({
      userName: ['', CustomValidators.compose([CustomValidators.required])],
      password: ['', CustomValidators.compose([Validators.required])]
    })
     
  }
  async login() {
    if (this.loginForm.valid) {
      this.issLoading = true;

      const success = await this.userService.login(this.loginForm.value);
      if (success) 
      { this.ngOnInit()
        this.issLoading = false;
       // this.router.navigateByUrl('HomePage');
        this.Login_Id=localStorage.getItem('Login_User');
        ROUTES.length = 0;
 
        Pointer_Table=new Array(200);  
        for(var i=0;i<Pointer_Table.length;i++)
        Pointer_Table[i]=-1;
        this.Menu_Service_.Get_Menu_Permission(this.Login_Id).subscribe( Rows => 
          {
        //   log(Rows)
            if(Rows!=null)
              {
                var Menus;
                Menus=Rows[0];

               
                Rows=[];
    for(var i=0;i<Menus.length;i++)
    {
      if(Menus[i].Menu_Id==1)
      this.Push_Menu({ path: '/User_Details', title: 'User Details', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type});
      else if(Menus[i].Menu_Id==2)
      this.Push_Menu({ path: '/Country', title: 'Country ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==3)
      this.Push_Menu({ path: '/Course', title: 'Course', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete ,Menu_Type:Menus[i].Menu_Type});
      else if(Menus[i].Menu_Id==4)
      this.Push_Menu({ path: '/Document', title: 'Document', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==5)
      this.Push_Menu({ path: '/Candidate', title: 'Client', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==6)
      this.Push_Menu({ path: '/Subject', title: 'Subject', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==7)
      this.Push_Menu({ path: '/University', title: 'University ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    //  else  if(Menus[i].Menu_Id==8)
    //  this.Push_Menu({ path: '/Home_Page', title: 'Home Page ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
       else  if(Menus[i].Menu_Id==9)
       this.Push_Menu({ path: '/Dashboard', title: 'Dashboard ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==10)
      this.Push_Menu({ path: '/Course_Import', title: 'Course Import ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==11)
      this.Push_Menu({ path: '/Account_Group', title: 'Account Group ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==12)
      this.Push_Menu({ path: '/Client_Accounts', title: 'Client Accounts ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==13)
      this.Push_Menu({ path: '/Agent', title: 'Agent ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==14)
      this.Push_Menu({ path: '/Department', title: 'Department', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==15)
      this.Push_Menu({ path: '/Branch', title: 'Branch ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==16)
      this.Push_Menu({ path: '/Department_Status', title: 'Department Status ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==17)
      this.Push_Menu({ path: '/Candidate_Report', title: 'Client Report ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==18)
      this.Push_Menu({ path: '/Remarks', title: 'Remarks', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==19)
      this.Push_Menu({ path: '/Work_report', title: 'Work Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==20)
      this.Push_Menu({ path: '/Enquiry_Source', title: 'Enquiry Source', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==21)
      this.Push_Menu({ path: '/TimeTrack', title: 'Time Track', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==22)
      this.Push_Menu({ path: '/Registration', title: 'Enrollment', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==23)
      this.Push_Menu({ path: '/Remove Enrollment', title: 'Remove Enrollment', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==24)
      this.Push_Menu({ path: '/Registration_Report', title: 'Enrollment Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type  });
      else  if(Menus[i].Menu_Id==25)
      this.Push_Menu({ path: '/Enquiry_Source_Report', title: 'Enquiry Source Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==26)
      this.Push_Menu({ path: '/Efficiency_Report', title: 'Efficiency Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==27)
      this.Push_Menu({ path: '/Candidate_Import', title: 'Client Import', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==28)
      this.Push_Menu({ path: '/Pending_FollowUp', title: 'Enquiry Pending Follow Up ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==29)
      this.Push_Menu({ path: '/Fees', title: 'Fees', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==30)
      this.Push_Menu({ path: '/Fees_Receipt_Report', title: 'Fees Receipt Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==31)
      this.Push_Menu({ path: '/Fees_Collection', title: 'Fees Collection ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==32)
      this.Push_Menu({ path: '/Enquiry_Source_Summary', title: 'Enquiry Source Summary ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==33)
      this.Push_Menu({ path: '/Counselor_Fees_Receipt_Report', title: 'Counselor Fees Receipt Report  ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==34)
      this.Push_Menu({ path: '/Counselor_Registration_Report', title: 'Counselor Enrollment Report ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==35)
      this.Push_Menu({ path: '/Candidate_Summary_Report', title: 'Client Summary Report ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==36)
      this.Push_Menu({ path: '/Staff_Target_Report', title: 'Staff Target Report ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==37)
      this.Push_Menu({ path: '/Candidate_Search', title: 'Client Search ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==38)
      {
        ;
        this.Push_Menu({ path: '/Export_Permission', title: 'Export Permission ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      }
      // else  if(Menus[i].Menu_Id==39)
      // this.Push_Menu({ path: '/Work_Summary', title: 'Work Summary ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==40)
      this.Push_Menu({ path: '/Application_Tab', title: 'Application Tab ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:0 });
      else  if(Menus[i].Menu_Id==41)
      this.Push_Menu({ path: '/Search_Course_Tab', title: 'Search Course Tab ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==42)
      this.Push_Menu({ path: '/Fees_Collection_Tab', title: 'Fees Collection Tab ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:0 });
      // else  if(Menus[i].Menu_Id==43)
      // this.Push_Menu({ path: '/Userwise_Summary', title: 'Userwise Receipt Summary ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      // else  if(Menus[i].Menu_Id==44)
      // this.Push_Menu({ path: '/Branchwise_Summary', title: 'Branchwise Summary ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==45)
      this.Push_Menu({ path: '/Statistics_Tab', title: 'Statistics Tab ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:0});
      else  if(Menus[i].Menu_Id==46)
      this.Push_Menu({ path: '/PageA', title: 'PageA ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==47)
      this.Push_Menu({ path: '/PageB', title: 'PageB ', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==48)
      this.Push_Menu({ path: '/PageC', title: 'PageC', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==49)
      this.Push_Menu({ path: '/Document_View', title: 'Document View', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==50)
      this.Push_Menu({ path: '/Receipt_Summary_Report', title: 'Receipt Summary Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==51)
      this.Push_Menu({ path: '/Registration_Summary', title: 'Enrollment Summary', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==52)
      this.Push_Menu({ path: '/Enquiry_Conversion', title: 'Enquiry Conversion', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==53)
      this.Push_Menu({ path: '/Employee_Summary', title: 'Employee Performance', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==54)
      this.Push_Menu({ path: '/User_Role', title: 'User Role', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==55)
      this.Push_Menu({ path: '/Company', title: 'Company', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==56)
      this.Push_Menu({ path: '/Settings', title: 'General Settings', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==57)
      this.Push_Menu({ path: '/Documentation_Report', title: 'My Candidates', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==58)
      this.Push_Menu({ path: '/Work_History', title: 'Work History', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==59)
      this.Push_Menu({ path: '/Registration_EnquirySource', title: 'Enrollment By EnquirySource', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==62)
      this.Push_Menu({ path: '/Check_List', title: 'Check List', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      
      else  if(Menus[i].Menu_Id==66)
      this.Push_Menu({ path: '/Agent_Details', title: 'Agent Details', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

      else  if(Menus[i].Menu_Id==67)
      this.Push_Menu({ path: '/Application_Report', title: 'Application Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
  
      else  if(Menus[i].Menu_Id==70)
      this.Push_Menu({ path: '/Intake', title: 'Intake', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==71)
      this.Push_Menu({ path: '/Task', title: 'Task', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==74)
      this.Push_Menu({ path: '/Notification', title: 'Notification', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==91)
      this.Push_Menu({ path: '/Receipt_Confirmation', title: 'Receipt Confirmation', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==92)
      this.Push_Menu({ path: '/Refund_Confirmation', title: 'Refund Confirmation', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==93)
      this.Push_Menu({ path: '/Refund_Approval', title: 'Refund Approval', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else  if(Menus[i].Menu_Id==94)
      this.Push_Menu({ path: '/Application_Dashboard', title: 'Application Dashboard', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==95)
      this.Push_Menu({ path: '/Candidate_Task', title: 'Task', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      else if(Menus[i].Menu_Id==150)
      this.Push_Menu({ path: '/B2B_Agencies', title: 'B2B Agents', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      else if(Menus[i].Menu_Id==156)
      this.Push_Menu({ path: '/Employer_Details', title: 'Employer Details', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    


      else if(Menus[i].Menu_Id==96)
      this.Push_Menu({ path: '/Passport_Expiry_Report', title: 'Passport Expiry Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==100)
      this.Push_Menu({ path: '/Application_Status', title: 'Application Status', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==101)
      this.Push_Menu({ path: '/Task_Item', title: 'Task Item', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==103)
      this.Push_Menu({ path: '/New_Task', title: 'New Task', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      // else if(Menus[i].Menu_Id==73)
      // this.Push_Menu({ path: '/Passport_Expiry_Report', title: 'Passport Expiry Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==104)
      this.Push_Menu({ path: '/Application_List', title: 'Application List', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

      else if(Menus[i].Menu_Id==123)
      this.Push_Menu({ path: '/Data_Migration', title: 'Data Migration', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      else if(Menus[i].Menu_Id==106)
      this.Push_Menu({ path: '/Create New application', title: 'Create New application', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==107)
      this.Push_Menu({ path: '/Application List Section', title: 'Application List Section', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==108)
      this.Push_Menu({ path: '/Application List Offerchasing Section', title: 'Application List Offerchasing Section', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==120)
      this.Push_Menu({ path: '/Accounts', title: 'Accounts', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

      else if(Menus[i].Menu_Id==121)
      this.Push_Menu({ path: '/Agent Application List', title: 'Agent Application List', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==122)
      this.Push_Menu({ path: '/Application No View', title: 'Application No View', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==124)
      this.Push_Menu({ path: '/Fees_Pending_Report', title: 'Fees Pending Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

      else if(Menus[i].Menu_Id==126)
      this.Push_Menu({ path: '/Class_Summary', title: 'Class Summary', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

      else if(Menus[i].Menu_Id==127)
      this.Push_Menu({ path: '/Class', title: 'Class', icon:
'unarchive', class:
'',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All,
Save:Menus[i].Menu_Save
,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type
});

    
      else if(Menus[i].Menu_Id==105)
      this.Push_Menu({ path: '/Application_Settings', title: 'Application Settings', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==109)
      this.Push_Menu({ path: '/Documents', title: 'Documents', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==110){
        this.Push_Menu({ path: '/Enrolled_Application_Only', title: 'Enrolled Application Only', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
        this.Permissions = Menus[i];
        if (this.Permissions!= undefined)
        
          if (this.Permissions.VIew_All ==  1) 
            localStorage.setItem('Enrolled_Application',this.Permissions.VIew_All);
          }


          else if(Menus[i].Menu_Id==111)
          this.Push_Menu({ path: '/DocumentName', title: 'Document', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==112)
          this.Push_Menu({ path: '/Application History Delete', title: 'Application History Delete', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==113){
            this.Push_Menu({ path: '/Application_View', title: 'Application View', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
            
            
            this.Permissions = Menus[i];
            if (this.Permissions!= undefined)
            
              if (this.Permissions.VIew_All ==  1) 
                localStorage.setItem('View_Permission',this.Permissions.VIew_All);
          }
          else if(Menus[i].Menu_Id==128)
          this.Push_Menu({ path: '/Enquirywise_Status_Report', title: 'Enquirywise Status Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==129)
          this.Push_Menu({ path: '/Department_Status_Report', title: 'Department Status Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          // else if(Menus[i].Menu_Id==130)
          // this.Push_Menu({ path: '/FollowUp_Status_Report', title: 'FollowUp Status Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });

          else if(Menus[i].Menu_Id==130)
          this.Push_Menu({ path: '/Department_Report', title: 'Department Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==132)
          this.Push_Menu({ path: '/Attendance_Report', title: 'Attendance Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==133)
          this.Push_Menu({ path: '/Reference', title: 'Reference', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==134)
          this.Push_Menu({ path: '/Task_Followup_Report', title: 'Task Followup Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
        
          else if(Menus[i].Menu_Id==135)
          this.Push_Menu({ path: '/Tag', title: 'Tag', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==136)
          this.Push_Menu({ path: '/Tag_Category', title: 'Tag Category', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==137)
          this.Push_Menu({ path: '/Maximum_Qualification', title: 'Specialization', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==138)
          this.Push_Menu({ path: '/Level', title: 'Maximum Qualification', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==139)
          this.Push_Menu({ path: '/Job_Posting', title: 'Job Posting', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
          else if(Menus[i].Menu_Id==140)
          this.Push_Menu({ path: '/Job_Posting_Tab', title: 'Job Posting Tab', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
        
          
      else if(Menus[i].Menu_Id==141)
      this.Push_Menu({ path: '/Agent_Data', title: 'Agent Data', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });



      else if(Menus[i].Menu_Id==142)
      this.Push_Menu({ path: '/Agent_Data', title: 'Study', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==143)
      this.Push_Menu({ path: '/Agent_Data', title: 'Job', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==144)
      this.Push_Menu({ path: '/Agent_Data', title: 'Immigration', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });


      else if(Menus[i].Menu_Id==145)
      this.Push_Menu({ path: '/Job_Category', title: 'Job Category', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==146)
      this.Push_Menu({ path: '/Job', title: 'Job', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==147)
      this.Push_Menu({ path: '/Pending_Fees_Report', title: 'Pending Fees Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==148)
      this.Push_Menu({ path: '/Enquiry_report', title: 'Enquiry Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==149)
      this.Push_Menu({ path: '/Chat_Window', title: 'Chat', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
     
      else if(Menus[i].Menu_Id==151)
      this.Push_Menu({ path: '/Work_Details_Report', title: 'Work Details Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
     
      else if(Menus[i].Menu_Id==152)
      this.Push_Menu({ path: '/Employer', title: 'Employer', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type }); 
      else if(Menus[i].Menu_Id==153)
      this.Push_Menu({ path: '/Job_Summary', title: 'Job Summary', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type }); 
      

      else if(Menus[i].Menu_Id==154)
      this.Push_Menu({ path: '/Interview_Report', title: 'Upcoming Interview', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      
      else if(Menus[i].Menu_Id==171)
      this.Push_Menu({ path: '/Visa_Report', title: 'Visa Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      
      else if(Menus[i].Menu_Id==155)
      this.Push_Menu({ path: '/Pending_Task_Report', title: 'Pending Task Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==157)
      this.Push_Menu({ path: '/Tomorrows_followup', title: 'Upcoming followup Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });  
      
      else if(Menus[i].Menu_Id==158)
      this.Push_Menu({ path: '/Employer_Dashboard', title: 'RECRUIT CRM', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type }); 
      else if(Menus[i].Menu_Id==159)
      this.Push_Menu({ path: '/Employer_Pending_FollowUp', title: 'Employer Pending FollowUp', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });   
      else if(Menus[i].Menu_Id==160)
      this.Push_Menu({ path: '/Employers_Tomorrows_followup', title: 'Employer Upcoming followup', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });   
    
      else if(Menus[i].Menu_Id==161)
      this.Push_Menu({ path: '/Employers_Today_followup', title: 'Employer Todays followup', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type }); 
    
      else if(Menus[i].Menu_Id==162)
      this.Push_Menu({ path: '/Agent_Data', title: 'Visa', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type }); 
      else if(Menus[i].Menu_Id==164)
      this.Push_Menu({ path: '/Agreed_Employer', title: 'Client Data', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });     
   
      else if(Menus[i].Menu_Id==163)
      this.Push_Menu({ path: '/Todo', title: 'Daily Call List', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });   

      else if(Menus[i].Menu_Id==165)
      this.Push_Menu({ path: '/Candidate_Document_Report', title: 'Candidate Document Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
    
      else if(Menus[i].Menu_Id==166)
      this.Push_Menu({ path: '/Monthly_Sales_Report', title: 'Monthly Sales Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });
      else if(Menus[i].Menu_Id==167)
      this.Push_Menu({ path: '/Job_Interview_Report', title: 'Job Interview Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
      else if(Menus[i].Menu_Id==168)
      this.Push_Menu({ path: '/Meeting_Followup', title: 'Meeting Followup', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
     
      else if(Menus[i].Menu_Id==169)
      this.Push_Menu({ path: '/Milestone', title: 'Milestone', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
       
      else if(Menus[i].Menu_Id==170)
      this.Push_Menu({ path: '/Pending_Interview_Report', title: 'New Resumes', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
      
      else if(Menus[i].Menu_Id==172)
      this.Push_Menu({ path: '/Job_Dashboard', title: 'Job Dashboard', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
      
      else if(Menus[i].Menu_Id==173)
      this.Push_Menu({ path: '/Interview_Outcome_Report', title: 'Interview Outcome Report', icon: 'unarchive', class: '',Menu_Id:Menus[i].Menu_Id,'View':Menus[i].VIew_All, Save:Menus[i].Menu_Save ,Edit:Menus[i].Menu_Edit,Delete:Menus[i].Menu_Delete,Menu_Type:Menus[i].Menu_Type });      
    
    }
 
localStorage.setItem("Routes_Temp",JSON.stringify(ROUTES));
localStorage.setItem("Pointer_Temp",JSON.stringify(Pointer_Table));
              this.router.navigateByUrl('Dashboard');
  }
},
Rows => { 
     
});
  }
 else
  {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Inavlid User Name/Password', Type:"3"}});
  }
}
}
  Push_Menu(Menu_Data)
  {
    ROUTES.push(Menu_Data);
    Pointer_Table[Menu_Data.Menu_Id-1] = ROUTES.length-1;
  }
	ngOnInit() {
		if (navigator.geolocation) {
		  debugger;
		  navigator.geolocation.getCurrentPosition(
			(position) => {
			  debugger;
			  console.log(position);
			  debugger;
			  this.latitude = position.coords.latitude;
			  this.longitude = position.coords.longitude;

			  console.log(this.latitude);
			  console.log(this.longitude);
	
			  // Reverse geocode to get the location name (city and area)
			  debugger;
			  this.reverseGeocode(this.latitude, this.longitude);
			},
			(error) => {
			  this.error = 'Error getting location: ' + error.message;
			}
		  );
		} else {
		  this.error = 'Geolocation is not supported by your browser.';
		}
	  }

    reverseGeocode(latitude: number, longitude: number) {
      debugger;
      const nominatimApiUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
    
      this.http.get(nominatimApiUrl).subscribe(
        (data: any) => {
        debugger;
        if (data && data.address) {
          this.city = data.address.city;
          this.suburb = data.address.suburb;
          this.county = data.address.county;
          this.country = data.address.country;
          this.state_district =data.address.state_district;
          this.postcode=data.address.postcode;
          this.country_code=data.address.country_code;
          this.lat=this.latitude.toString();
          this.long=this.longitude.toString();
        
          if(this.city == undefined || this.city == "undefined" || this.city == null){
            this.city = "";
            }
            if(this.suburb == undefined || this.suburb == "undefined" || this.suburb == null){
            this.suburb = "";
            }
            if(this.county == undefined || this.county == "undefined" || this.county == null){
            this.county = "";
            }
            if(this.state_district == undefined || this.state_district == "undefined" || this.state_district == null){
            this.state_district = "";
            }
            if(this.country == undefined || this.country == "undefined" || this.country == null){
            this.country = "";
            }
            if(this.postcode == undefined || this.postcode == "undefined" || this.postcode == null){
            this.postcode = "";
            }
            if(this.country_code == undefined || this.country_code == "undefined" || this.country_code == null){
            this.country_code = "";
            }
          console.log(this.county);
  debugger;
              this.uid = Number(localStorage.getItem("Login_User"));
              // this.caid = Number(localStorage.getItem("Client_Accounts_Id"));
              console.log(this.uid);
              this.Student_Service_.Login_Location(this.uid,this.lat,this.long,this.city,this.suburb,this.county,this.state_district,this.country,
                this.postcode,this.country_code).subscribe((Rows) => {
    // debugger;
                    console.log(Rows);
          localStorage.setItem("city", this.city);
          localStorage.setItem("suburb", this.suburb);
          localStorage.setItem("county", this.county);
          localStorage.setItem("country", this.country);
          localStorage.setItem("state_district", this.state_district);
          localStorage.setItem("postcode", this.postcode);
          localStorage.setItem("country_code", this.country_code);
      
          localStorage.setItem("latitude", this.latitude.toString());
          localStorage.setItem("longitude", this.longitude.toString());
    
  });
         
  
  
    
    
    
    
        } else {
          this.error = 'Location not found.';
        }
        },
        (error) => {
        this.error = 'Error fetching location data: ' + error.message;
        }
      );
      }
}