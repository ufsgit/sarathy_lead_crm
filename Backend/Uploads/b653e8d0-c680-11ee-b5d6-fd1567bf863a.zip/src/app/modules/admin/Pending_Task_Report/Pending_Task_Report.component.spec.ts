import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {Pending_Task_ReportComponent}  from './Pending_Task_Report.component';
describe('Refund_Approval', () => {
let component: Pending_Task_ReportComponent;
let fixture: ComponentFixture<Pending_Task_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Pending_Task_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Pending_Task_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

