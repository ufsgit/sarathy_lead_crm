import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Enquiry_Source} from '../../../models/Enquiry_Source';
import { Enquiry_Source_Service } from '../../../services/Enquiry_Source.service';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Reference } from 'app/models/Reference';
// import { Reference } from '@angular/compiler/src/render3/r3_ast';
@Component({
selector: 'app-Reference',
templateUrl: './Reference.component.html',
styleUrls: ['./Reference.component.css']
})
export class ReferenceComponent implements OnInit {
Enquiry_Source_Data:Enquiry_Source[]
Enquiry_Source_:Enquiry_Source= new Enquiry_Source();
Reference_:Reference= new Reference();
Reference_Data:Reference[];

Reference_Name_Search:string;
Enquiry_Source_Name_Search:string;


Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Enquiry_Source_Edit:boolean;
Enquiry_Source_Save:boolean;
Enquiry_Source_Delete:boolean;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";

constructor(public Enquiry_Source_Service_:Enquiry_Source_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));

// this.Permissions = Get_Page_Permission(20);
// if(this.Permissions==undefined || this.Permissions==null)
// {
// localStorage.removeItem('token');
// this.router.navigateByUrl('Home_Page');
// }
// else
{
// this.Enquiry_Source_Edit=this.Permissions.Edit;
// this.Enquiry_Source_Save=this.Permissions.Save;
// this.Enquiry_Source_Delete=this.Permissions.Delete;
this.Page_Load()
}
}
Page_Load()
{
this.myInnerHeight = (window.innerHeight);
this.myInnerHeight = this.myInnerHeight - 250;
this.Clr_Enquiry_Source();
this.Get_Menu_Status(20,this.Login_User);

this.Search_Enquiry_Source();
this.Entry_View=false;

this.myInnerHeight = (window.innerHeight);
this.myTotalHeight=this.myInnerHeight - 200;
this.myTotalHeight=this.myTotalHeight-90;
this.myInnerHeight = this.myInnerHeight - 230;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
this.issLoading = true;
this.Enquiry_Source_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            
  
    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==20)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==20)
        {
            
        

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
                this.Enquiry_Source_Edit=this.Permissions.Edit;
                this.Enquiry_Source_Save=this.Permissions.Save;
                this.Enquiry_Source_Delete=this.Permissions.Delete;
    
        }

    }

},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}

Create_New()
{
this.Entry_View = true;
this.Clr_Enquiry_Source();
}
Close_Click()
{
this.Entry_View = false;

}
trackByFn(index, item) 
{
return index;
}

 Clr_Enquiry_Source()
 {
this.Reference_.Reference_Id=0;
this.Reference_.Reference_Name="";
}

Search_Enquiry_Source()
{debugger;
this.issLoading=true;
// this.Reference_Name_Search='a';
debugger;
this.Enquiry_Source_Service_.Search_Reference(this.Reference_Name_Search).subscribe(Rows => {
 this.Reference_Data=Rows[0];
 debugger;
this.Total_Entries=this.Reference_Data.length;
if(this.Reference_Data.length==0)
{
this.issLoading=false;
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}

Delete_Enquiry_Source(Reference_Id,index)
{debugger;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
this.Search_Enquiry_Source();
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
this.issLoading=true;
this.Enquiry_Source_Service_.Delete_Reference(Reference_Id).subscribe(Delete_status => {
    debugger;
if(Number(Delete_status[0][0].Reference_Id_)>0){
this.Reference_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_Enquiry_Source();
}else if(Number(Delete_status[0][0].Reference_Id_)== -2)
{debugger;
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}
Save_Enquiry_Source()
{

    if (this.Reference_.Reference_Name == undefined || this.Reference_.Reference_Name== null || this.Reference_.Reference_Name == undefined || this.Reference_.Reference_Name=='') {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Reference', Type: "3" } });
       return;
    }
    
this.issLoading=true;
debugger;
this.Enquiry_Source_Service_.Save_Reference(this.Reference_).subscribe(Save_status => {
    debugger;
Save_status=Save_status[0];
if(Number(Save_status[0].Reference_Id_)>0)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
this.Search_Enquiry_Source();
this.Clr_Enquiry_Source();
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error,Type:"2"}});
 });
 
}
Edit_Enquiry_Source(Reference_e:Reference,index)
{
   
this.Entry_View=true;
this.Reference_=Reference_e;
this.Reference_=Object.assign({},Reference_e);
}
}



