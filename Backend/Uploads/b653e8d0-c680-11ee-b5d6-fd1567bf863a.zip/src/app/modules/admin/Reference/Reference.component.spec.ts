import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReferenceComponent } from './Reference.component';
describe('ReferenceComponent', () => {
let component: ReferenceComponent;
let fixture: ComponentFixture<ReferenceComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ ReferenceComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(ReferenceComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});