import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Visa_ReportComponent } from './Visa_Report.component';

describe('Visa_ReportComponent', () => {
  let component: Visa_ReportComponent;
  let fixture: ComponentFixture<Visa_ReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Visa_ReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Visa_ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
