import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Work_Details_ReportComponent} from './Work_Details_Report.component';
describe('Home_PageComponent', () => {
let component: Work_Details_ReportComponent;
let fixture: ComponentFixture<Work_Details_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Work_Details_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Work_Details_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

