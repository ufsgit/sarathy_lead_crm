import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { University_Service } from '../../../services/University.service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { University } from '../../../models/University';
import { Status } from '../../../models/Status';
import {MatDialog} from '@angular/material';
import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
@Component({
selector: 'app-University',
templateUrl: './University.component.html',
styleUrls: ['./University.component.css']
})
export class UniversityComponent implements OnInit {
University_Data:University[]
University_:University= new University();
University_Search:University=new University();

University_Name_Search:string;

Entry_View:boolean=true;
profile_View:boolean=true;
application_View:boolean=true;

EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
myInnerHeight: number;

University_Edit:boolean;
University_Save:boolean;
University_Delete:boolean;

Status_:Status=new Status();
Status_Data:Status[];
Status_Search:Status=new Status();

ImageFile: any;
File: string;

University_File:string
University_Image:any;
University_Photo=[];
Login_User:string='0';
constructor(public University_Service_:University_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));
    this.issLoading=true;   
    this.Page_Load()
  
}
Page_Load()
{ 
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 230;
    this.Get_Menu_Status(7, this.Login_User)
    this.Clr_University();
    this.Search_University();
    this.Entry_View=false;
    this.profile_View=true;
    this.application_View=true;


    
    
}
Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.University_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==7)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==7)
        {
            
           

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               
                this.University_Edit=this.Permissions.Edit;
                this.University_Save=this.Permissions.Save;
                this.University_Delete=this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}
Create_New()
{
    this.Entry_View = true;
    this.Clr_University();
    this.profile_View=true;
    this.application_View=false;
}
Close_Click()
{
    this.Entry_View = false;
}
trackByFn(index, item) 
{
    return index;
}
Clr_University()
 {
this.University_.University_Id=0;
this.University_.University_Name="";

}
Search_University()
{
this.issLoading=true;
this.University_Service_.Search_University(this.University_Name_Search).subscribe(Rows => {
     
 this.University_Data=Rows[0];
this.Total_Entries=this.University_Data.length;
if(this.University_Data.length==0)
{
this.issLoading=false;
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}


Delete_University(University_Id,index)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});

dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
this.issLoading=true;
this.University_Service_.Delete_University(University_Id).subscribe(Delete_status => {
if(Delete_status[0][0].University_Id_>0){
this.University_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_University();
}else if(Number(Delete_status[0][0].University_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}
Save_University()
{

    if (this.University_.University_Name == undefined || this.University_.University_Name == null || this.University_.University_Name == undefined || this.University_.University_Name=='') {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter University', Type: "3" } });
       return;
    }
    


this.issLoading=true;
this.University_Service_.Save_University(this.University_).subscribe(Save_status => {
Save_status=Save_status[0];
if(Number(Save_status[0].University_Id_)>0)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
this.Search_University();
this.Clr_University();
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error.error,Type:"2"}});
 });
}
Edit_University(University_e:University,index)
{
this.Entry_View=true;
this.University_=University_e;
this.University_=Object.assign({},University_e);
}
}


