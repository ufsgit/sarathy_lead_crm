import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Tag_CategoryComponent } from './Tag_Category.component';
describe('TagComponent', () => {
let component: Tag_CategoryComponent;
let fixture: ComponentFixture<Tag_CategoryComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Tag_CategoryComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Tag_CategoryComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

