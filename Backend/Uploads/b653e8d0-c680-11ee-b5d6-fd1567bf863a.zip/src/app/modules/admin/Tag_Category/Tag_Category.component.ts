import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Intake_Service } from '../../../services/Intake.service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Intake } from '../../../models/Intake';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Tag_Category } from 'app/models/Tag_Category';
import { Enquiry_For } from 'app/models/Enquiry_For';
import { Tag_Category_Enquiry_For } from 'app/models/Tag_Category_Enquiry_For';
import { Student_Service } from 'app/services/Student.Service';
@Component({
selector: 'app-Tag_Category',
templateUrl: './Tag_Category.component.html',
styleUrls: ['./Tag_Category.component.css']
})
export class Tag_CategoryComponent implements OnInit {
Intake_Data:Intake[]
Intake_:Intake= new Intake();
Intake_Name_Search:string;
Tag_Category_Data:Tag_Category[]
Tag_Category_:Tag_Category= new Tag_Category();
Tag_Category_Name_Search:string;
Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Intake_Edit:boolean;
Intake_Save:boolean;
Intake_Delete:boolean;
Tag_Category_Edit:boolean;
Tag_Category_Save:boolean;
Tag_Category_Delete:boolean;
myInnerHeight: number;
Login_User:string='0';

Enquiry_For_Data: Enquiry_For[];
Enquiry_For_Data_Temp: any = [];
Enquiry_For_Data_Edit: any;




constructor
(
    public Intake_Service_:Intake_Service, 
    private route: ActivatedRoute, 
    private router: Router,
    public dialogBox: MatDialog,
    public Student_Service_:Student_Service,
) { }
ngOnInit() 
{

    this.Login_User=localStorage.getItem(("Login_User"));
    
    this.Page_Load();
}
Page_Load()
{
this.myInnerHeight = (window.innerHeight);
this.myInnerHeight = this.myInnerHeight - 250;
this.Get_Menu_Status(136, this.Login_User);
this.Load_Enquiryfor();
this.Clr_Tag_Category();
this.Search_Tag_Category();
this.Entry_View=false;
}
Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Intake_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==136)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==136)
        {
            
           

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               debugger
                this.Tag_Category_Edit=this.Permissions.Edit;
                this.Tag_Category_Save=this.Permissions.Save;
                this.Tag_Category_Delete=this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}
Create_New()
{
this.Entry_View = true;
this.Clr_Tag_Category();
}
Close_Click()
{
    this.Clr_Tag_Category();
this.Entry_View = false;

}
trackByFn(index, item) 
{
return index;
}

 Clr_Tag_Category()
 {
    debugger;
this.Tag_Category_.Tag_Category_Id=0;
this.Tag_Category_.Tag_Category_Name="";
this.Tag_Category_Save=true;

if (this.Enquiry_For_Data != undefined) {
    for (var i = 0; i < this.Enquiry_For_Data.length; i++) 
    {
        this.Enquiry_For_Data[i].Is_Check = false;
    }
}

}
Search_Tag_Category()
{
this.issLoading=true;
this.Intake_Service_.Search_Tag_Category(this.Tag_Category_Name_Search).subscribe(Rows => {
 this.Tag_Category_Data=Rows[0];
this.Total_Entries=this.Tag_Category_Data.length;
if(this.Tag_Category_Data.length==0)
{
this.issLoading=false;
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
Delete_Tag_Category(Tag_Category_Id,index)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
this.issLoading=true;
this.Intake_Service_.Delete_Tag_Category(Tag_Category_Id).subscribe(Delete_status => {
    debugger
if(Delete_status[0][0].Tag_Category_Id_>0){
this.Tag_Category_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_Tag_Category();
}else if(Number(Delete_status[0][0].Tag_Category_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Cannot Delete!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}
Save_Tag_Category()

{
    debugger
    
    if (this.Tag_Category_.Tag_Category_Name == undefined || this.Tag_Category_.Tag_Category_Name == null || this.Tag_Category_.Tag_Category_Name == undefined || this.Tag_Category_.Tag_Category_Name=='') {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Tag Category', Type: "3" } });
       return;
    }

    this.Enquiry_For_Data_Temp = [];
    for (var i = 0; i < this.Enquiry_For_Data.length; i++) {
        if (
            Boolean(this.Enquiry_For_Data[i].Is_Check) == true ||
            Boolean(this.Enquiry_For_Data[i].Is_Check) == false
        ) {
            this.Enquiry_For_Data_Temp.push(this.Enquiry_For_Data[i]);
        }
    }
    this.Tag_Category_.Enquiry_For_Data = this.Enquiry_For_Data_Temp;

    ;

    var temp_Enquiry_For = "";
    for (var i = 0; i < this.Enquiry_For_Data.length; i++) {
        if (this.Enquiry_For_Data[i].Is_Check == true) {
            temp_Enquiry_For += "*" + this.Enquiry_For_Data[i].Enquiryfor_Id + "*";
        }
    }


    this.Tag_Category_.Tag_Category_Enquiry_For = temp_Enquiry_For;

this.Tag_Category_Save=false;
this.issLoading=true;
this.Intake_Service_.Save_Tag_Category(this.Tag_Category_).subscribe(Save_status => {
    debugger
Save_status=Save_status[0];
if(Number(Save_status[0].Tag_Category_Id_)>0)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
this.Search_Tag_Category();
this.Clr_Tag_Category();
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error.error,Type:"2"}});
 });
}

Edit_Tag_Category(Tag_Category_e:Tag_Category,index)
{   
    debugger;
    this.Entry_View=true;
    this.Tag_Category_=Tag_Category_e;
    this.Tag_Category_=Object.assign({},Tag_Category_e);
    debugger;
    this.Intake_Service_.Get_enquiry_for_tag_category(Tag_Category_e.Tag_Category_Id).subscribe(
        (Rows) => {	
            debugger;
            this.Enquiry_For_Data_Edit = Rows[0];

            
				for (var i = 0; i < this.Enquiry_For_Data.length; i++) {
					for (var j = 0; j < this.Enquiry_For_Data_Edit.length; j++) {
						if (this.Enquiry_For_Data[i].Enquiryfor_Id == this.Enquiry_For_Data_Edit[j].Enquiryfor_Id) {
							this.Enquiry_For_Data[i].Is_Check = true;
						}
					}
				}
                debugger;

        },


        (Rows) => {
            this.issLoading = false;
            const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
        }
    );

    }

	Load_Enquiryfor() 
    {
        debugger;
		this.issLoading = true;
		this.Student_Service_.Load_Enquiryfor().subscribe(
			(Rows) => {
                debugger;
				if (Rows != null) 
                {
					this.Enquiry_For_Data = Rows[0];
					
					this.issLoading = false;
	            }
                debugger;
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}
}

