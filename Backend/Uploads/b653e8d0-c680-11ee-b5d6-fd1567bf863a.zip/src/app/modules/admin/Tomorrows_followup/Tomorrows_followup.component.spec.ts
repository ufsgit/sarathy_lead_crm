import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Tomorrows_followupComponent } from './Tomorrows_followup.component';

describe('Tomorrows_followupComponent', () => {
  let component: Tomorrows_followupComponent;
  let fixture: ComponentFixture<Tomorrows_followupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Tomorrows_followupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Tomorrows_followupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
