import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {Student_Task_Followup_ReportComponent}  from './Student_Task_Followup_Report.component';
describe('Refund_Approval', () => {
let component: Student_Task_Followup_ReportComponent;
let fixture: ComponentFixture<Student_Task_Followup_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Student_Task_Followup_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Student_Task_Followup_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

