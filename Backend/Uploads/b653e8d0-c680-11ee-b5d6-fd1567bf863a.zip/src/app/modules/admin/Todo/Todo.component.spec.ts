import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {TodoComponent}  from './Todo.component';
describe('Refund_Approval', () => {
let component: TodoComponent;
let fixture: ComponentFixture<TodoComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ TodoComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(TodoComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

