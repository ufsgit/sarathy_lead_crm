import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Intake_Service } from '../../../services/Intake.service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Intake } from '../../../models/Intake';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Tag } from 'app/models/Tag';
import { Tag_Category } from 'app/models/Tag_Category';
@Component({
selector: 'app-Tag',
templateUrl: './Tag.component.html',
styleUrls: ['./Tag.component.css']
})
export class TagComponent implements OnInit {
Intake_Data:Intake[]
Intake_:Intake= new Intake();
Intake_Name_Search:string;
Tag_Data:Tag[]
Tag_:Tag= new Tag();
Tag_Name_Search:string;
Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Intake_Edit:boolean;
Intake_Save:boolean;
Intake_Delete:boolean;
Tag_Edit:boolean;
Tag_Save:boolean;
Tag_Delete:boolean;
myInnerHeight: number;
Login_User:string='0';

Tag_Category_Dropdown_:Tag_Category= new Tag_Category();
Tag_Category_Dropdown_Temp:Tag_Category= new Tag_Category();
Tag_Category_Dropdown_Data:Tag_Category[];
constructor(public Intake_Service_:Intake_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{

    this.Login_User=localStorage.getItem(("Login_User"));
    
    this.Page_Load();
}
Page_Load()
{
this.myInnerHeight = (window.innerHeight);
this.myInnerHeight = this.myInnerHeight - 250;
this.Get_Menu_Status(135, this.Login_User);
this.Clr_Tag();
this.Search_Tag();
this.Load_TagCategory();
this.Entry_View=false;
}
Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Intake_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==135)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==135)
        {
            
           

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               
                this.Tag_Edit=this.Permissions.Edit;
                this.Tag_Save=this.Permissions.Save;
                this.Tag_Delete=this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}
Create_New()
{
this.Entry_View = true;
this.Clr_Tag();
}
Close_Click()
{
this.Entry_View = false;
}
trackByFn(index, item) 
{
return index;
}

 Clr_Tag()
 {

    this.Tag_Save=true;
this.Tag_.Tag_Id=0;
this.Tag_.Tag_Name="";

if (
    this.Tag_Category_Dropdown_Data != null &&
    this.Tag_Category_Dropdown_Data != undefined
)
    this.Tag_Category_Dropdown_ = this.Tag_Category_Dropdown_Data[0];

    

}


Load_TagCategory() {
    debugger
    this.issLoading = true;
    this.Intake_Service_.Load_TagCategory().subscribe(
      (Rows) => {
        debugger
        if (Rows != null) {
          this.Tag_Category_Dropdown_Data = Rows[0];
          this.Tag_Category_Dropdown_Temp.Tag_Category_Id = 0;
          this.Tag_Category_Dropdown_Temp.Tag_Category_Name = "Select";
          this.Tag_Category_Dropdown_Data.unshift(this.Tag_Category_Dropdown_Temp);
  
          this.Tag_Category_Dropdown_ = this.Tag_Category_Dropdown_Data[0];
          this.issLoading = false;
        }
      },
      (Rows) => {
        this.issLoading = false;
      }
    );
  }



Search_Tag()
{
this.issLoading=true;

this.Intake_Service_.Search_Tag(this.Tag_Name_Search).subscribe(Rows => {
 this.Tag_Data=Rows[0];
this.Total_Entries=this.Tag_Data.length;
if(this.Tag_Data.length==0)
{
this.issLoading=false;
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
Delete_Tag(Tag_Id,index)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
this.issLoading=true;
this.Intake_Service_.Delete_Tag(Tag_Id).subscribe(Delete_status => {
    debugger
if(Delete_status[0][0].Tag_Id_>0){
this.Tag_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_Tag();
}else if(Number(Delete_status[0][0].Tag_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Cannot Delete!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}
Save_Tag()
{
    this.Tag_.Tag_Category_Id=this.Tag_Category_Dropdown_.Tag_Category_Id
    this.Tag_.Tag_Category_Name=this.Tag_Category_Dropdown_.Tag_Category_Name
    if (this.Tag_.Tag_Name == undefined || this.Tag_.Tag_Name == null || this.Tag_.Tag_Name == undefined || this.Tag_.Tag_Name=='') {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Tag', Type: "3" } });
       return;
    }

    if (this.Tag_.Tag_Category_Id== undefined || this.Tag_.Tag_Category_Id == null || this.Tag_.Tag_Category_Id == 0) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Tag Category', Type: "3" } });
       return;
    }
    
// else{
//     debugger
//     document.getElementById("Save_Button").hidden=true;

this.Tag_Save=false;
this.issLoading=true;
this.Intake_Service_.Save_Tag(this.Tag_).subscribe(Save_status => {
    debugger
Save_status=Save_status[0];
if(Number(Save_status[0].Tag_Id_)>0)
{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
this.Search_Tag();
this.Clr_Tag();



}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error.error,Type:"2"}});
 });
// }
}
Edit_Tag(Tag_e:Tag,index)
{
    debugger
this.Entry_View=true;
this.Tag_=Tag_e;
this.Tag_=Object.assign({},Tag_e);

for (var i = 0; i < this.Tag_Category_Dropdown_Data.length; i++) {
    if (
        this.Tag_.Tag_Category_Id ==
        this.Tag_Category_Dropdown_Data[i].Tag_Category_Id
    )
        this.Tag_Category_Dropdown_ = this.Tag_Category_Dropdown_Data[i];
}

}





}

