import { Component, OnInit, Input, Injectable } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Observable, of as observableOf, merge } from "rxjs";
import { Student_Service } from "../../../services/Student.Service";
import { DialogBox_Component } from "../DialogBox/DialogBox.component";
import { Student } from "../../../models/Student";
import { Branch } from "../../../models/Branch";
import { User_Details } from "../../../models/User_Details";
import { Department } from "../../../models/Department";
import { Department_Status } from "../../../models/Department_Status";
import { Gender } from "../../../models/Gender";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";

import {
	ROUTES,
	Get_Page_Permission,
} from "../../../components/sidebar/sidebar.component";
import {
	MatDialog,
	MatDialogRef,
	MAT_DIALOG_DATA,
	MatDialogConfig,
} from "@angular/material";
import { FormControl } from "@angular/forms";
import { MomentDateAdapter } from "@angular/material-moment-adapter";
import {
	DateAdapter,
	MAT_DATE_FORMATS,
	MAT_DATE_LOCALE,
} from "@angular/material/core";
import * as _moment from "moment";
import { default as _rollupMoment } from "moment";
import { Remarks } from "../../../models/Remarks";
import { Student_FollowUp } from "../../../models/Student_FollowUp";
import { Enquiry_Source } from "../../../models/Enquiry_Source";
import { Internship_Service } from "../../../services/Internship.service";
import { Fees_Receipt_Status } from "../../../models/Fees_Receipt_Status";
import {  Task_Status } from "../../../models/Task_Status";
import { Student_Task } from "../../../models/Student_Task";
import { Task_Item } from "../../../models/Task_Item";
import{Employer_Source}from "../../../models/Employer_Source"
import { environment } from "../../../../environments/environment.js";
import { Task_Group } from "../../../models/Task_group";
import * as io from "socket.io-client";
import { Employer_Status } from "../../../models/Employer_Status";
import { Interview_Status } from "../../../models/Level_Detail copy";
import { Job_Category } from "app/models/Job_Category";
import { Job_Category_Service } from "app/services/Job_Category.Service";
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
	parse: {
		dateInput: "DD/MM/YYYY",
	},
	display: {
		dateInput: "DD/MM/YYYY",
		monthYearLabel: "MMM YYYY",
		dateA11yLabel: "DD/MM/YYYY",
		monthYearA11yLabel: "MMMM YYYY",
	},
};

@Component({
	selector: "app-Employer_Details",
	templateUrl: "./Employer_Details.component.html",
	styleUrls: ["./Employer_Details.component.css"],
	providers: [
		{
			provide: DateAdapter,
			useClass: MomentDateAdapter,
			deps: [MAT_DATE_LOCALE],
		},
		{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
	],
})
export class Employer_DetailsComponent implements OnInit {
	// private url = "http://localhost:3510";
	// private url = 'ws:http://regnewapi.trackbox.co.in:3646/'
	url = environment.NotificationPath; //'http://regnewapi.trackbox.co.in:3646/'
	private socket;
	Status_Search: Department_Status = new Department_Status();
	User_Search: User_Details = new User_Details();
	Search_Name = "";
	Department_Search: Department = new Department();
	Search_Branch: Branch = new Branch();
	Search_Task_Status: Task_Status = new Task_Status();
	Search_Fees_Receipt_Status: Fees_Receipt_Status = new Fees_Receipt_Status();
	Search_FromDate: Date = new Date();
	Search_ToDate: Date = new Date();
	Look_In_Date: Boolean = false;
	More_Search_Options: boolean = true;
	Save_Call_Status: boolean = false;


	Employer_Source_Data:Employer_Source[];
	Employer_Source_Temp:Employer_Source= new Employer_Source();
	Employer_Source_:Employer_Source= new Employer_Source();
	
	selectedPdfPreview: any='';
	pdfload: boolean = true;
	Enquiry_Source_Search_: Enquiry_Source = new Enquiry_Source();
	Enquiry_Source_: Enquiry_Source = new Enquiry_Source();
	Cas_Followup_View: boolean = false;
	Enquiry_Source_Data: Enquiry_Source[];
	Enquiry_Source_Search_Data: Enquiry_Source[];
	Enquiry_Source_Temp: Enquiry_Source = new Enquiry_Source();
	Enquiry_Source_Search_Temp: Enquiry_Source = new Enquiry_Source();

	Department_Data: Department[];
	FollowUp_Branch_Task_: Branch = new Branch();
	Users_Data: User_Details[];
	Branch_Data: Branch[];
	cas_task_id: number;
	cas_task_student_id: number;
	cas_task_item_id: number;
	cas_task_group_id: number;
	Cas_Followup_: Student_Task = new Student_Task();
	Temp_Date_Followup: Date;
	Student_Task_Data: Student_Task[];
	Job_Country_:number =0;
	Task_Status_Data: Task_Status[];

	Fees_Receipt_Status_Data: Fees_Receipt_Status[];
	Status_Data: Department_Status[];
	Gender_Data: Gender[];
	Branch_Temp1: Branch = new Branch();
	Fees_Receipt_Status_Temp: Fees_Receipt_Status = new Fees_Receipt_Status();
	Users_Temp: User_Details = new User_Details();
	Department_Temp: Department = new Department();
	Status_Temp: Department_Status = new Department_Status();
	missedfollowup_count: number = 1;
	followup_count: number = 1;
	FollowUp_: Student_FollowUp = new Student_FollowUp();
	Followup_Users_Task_: User_Details = new User_Details();
	Followup_Users_1_Temp_: User_Details = new User_Details();
	student_name: string;
	to_user_name: string;

	Lead_Data: Student[];
	Student_Data_Search: Student[];
	Task_Data_Search: Student_Task[];
	Student_Data: Student[];
	Student_Data_Item: Student = new Student();
	Lead_: Student = new Student();
	Search_Div: boolean = false;
	array: any;
	color = "primary";
	mode = "indeterminate";
	value = 50;
	myInnerHeight: number;
	myTotalHeight: number;
	issLoading: boolean;
	approve_reject_status: string;

	Refund_Approval_Comment_View: boolean = false;

	Total_Amount: number = 0;
	Total_Students: number = 0;
	Total_Registration: number = 0;
	Total_Entries: number = 0;

	Show_FollowUp: boolean = false;
	main_View: boolean = false;
	Student_Selected_Data: Student[];

	Black: boolean = false;
	Red: boolean = false;
	pagePointer: number = 0;
	pageindex2: number = 0;
	pageindex: number = 0;
	Total_Rows: number = 0;
	isLoading = false;
	Search_By_: any;
	Registered_By_: any;
	year: any;
	month: any;
	day: any;
	date: any;
	Login_User: string = "0";
	Menu_Id: number = 156;

	Select_Student: boolean = false;
	Select_View: boolean = false;
	Student_Id: number = 0;
	Student_: Student = new Student();

	Enquiry_Source_data_temp: [];
	RowCount: number = 0;
	RowCount2: number = 0;
	nextflag: number = -1;
	Page_Length_: number = 10;
	firstnum: number = 0;
	lastnum: number = 1;
	shownext: boolean = false;
	showprev: boolean = false;

	Followup_Branch_Data_Filter: Branch[];
	Black_Start: number = 1;
	Black_Stop: number = 0;
	Red_Start: number = 1;
	Red_Stop: number = 0;
	points25: boolean = false;
	Edit_Page_Permission: any;
	Comment: String;

	Student_Task_Id: number;



	latitude: number = 0; // Initialize with a default value
  	longitude: number = 0; // Initialize with a default value
  	city: string = '';
  	suburb: string = '';
  	county: string= '';
  	country: string ='';
  	state_district ='';
  	postcode='';
  	country_code='';
  	error: string = '';
    lat: string = '';
    long: string = '';

    Job_Category_1_Data: Job_Category[];
	Job_Category_1_Data_Filter: Job_Category[];
	Job_Category_1_: Job_Category = new Job_Category();
	Job_Category_1_Temp_: Job_Category = new Job_Category();



	Job_Users_Data: User_Details[];
	Job_Users_Data_Filter: User_Details[];
	Job_Users_: User_Details = new User_Details();
	User_Details_Temp_: User_Details = new User_Details();



	Followup_Users_Data: User_Details[];
	Followup_Users_Data_t: User_Details[];
	Followup_Users_Data_t_Filter: User_Details[];
	Followup_Users_Data_tN: Student_FollowUp[];
	Followup_Users_: User_Details = new User_Details();
	Followup_Users_t: User_Details = new User_Details();
	Followup_Users_temp: User_Details = new User_Details();

	Followup_Users_tN: Student_FollowUp = new Student_FollowUp();
	//Followup_Users_tempN: Student_FollowUp = new Student_FollowUp();
	Followup_Users_tempN: User_Details = new User_Details();

	FollowUp_Department_TN: Student_FollowUp = new Student_FollowUp();
	//FollowUp_Department_TempN: Student_FollowUp = new Student_FollowUp();
	FollowUp_Department_TempN: Department = new Department();
	Followup_Department_DataN: Student_FollowUp[];
	Followup_Department_Data_TN: Student_FollowUp[];
	Followup_Department_Data_CheckN: Student_FollowUp[];

	Student_Selection_Data_Temp: Student[];

	FollowUp_Status_: Department_Status = new Department_Status();

	Followup_Status_Data: Department_Status[];

	Lead_Fees_Receipt_Id: number;
	Department_1_Temp_: Department = new Department();
	FollowUp_Department_: Department = new Department();
	Followup_Department_Data: Department[];
	Followup_Department_Data_Check: Department[];
	FollowUp_Department_Task_: Department = new Department();
	FollowUp_Branch_: Branch = new Branch();
	Followup_Branch_Data: Branch[];
	Branch_Temp: Branch = new Branch();

	Remarks_: Remarks = new Remarks();
	Remarks_Data: Remarks[];
	Remarks_Temp: Remarks = new Remarks();
	Login_Id: number;
	Summary_Div: boolean = false;
	Login_User_Name: string;
	Interview_Status_Temp:Interview_Status = new Interview_Status();
	Interview_Status_:Interview_Status = new Interview_Status();
	Export_Permission: any;
	Export_View: boolean = false;
	Load_Graph = 0;
	Graph_Button: boolean = false;
	Enquiry_Source_title = "";
	Enquiry_Source_type = "PieChart";
	Enquiry_Source_data = [];
	Enquiry_Source_columnNames = [];
	Enquiry_Source_options = { is3D: true };
	width = 550;
	height = 400;
	Title_Bar = "Browser market shares at a specific website, 2014";
	Type_Bar = "BarChart";
	Data_Bar = [];
	columnNames_Bar = ["Browser", "Count"];
	options_Bar = { is3D: true };
	Permissions: any;

	Employer_Status_Data: Employer_Status[];
	Employer_Status_Temp:Employer_Status = new Employer_Status();
	Employer_Status_:Employer_Status = new Employer_Status();
	Employer_Status_Data_search: Employer_Status[];
	Employer_Status_search_: Employer_Status = new Employer_Status();
	Employer_Status_Temp_search_: Employer_Status = new Employer_Status();
	Task_Status_: Task_Status = new Task_Status();
	Task_Status_search_: Task_Status = new Task_Status();
	Task_Status_Temp_search: Task_Status = new Task_Status();
	Task_Status_Temp: Task_Status = new Task_Status();
	Task_Status_Data_search: Task_Status[];
	Task_Item_: Task_Item = new Task_Item();
	Task_Item_search_: Task_Item = new Task_Item();
	Task_Item_search_Tasknew_: Task_Item = new Task_Item();
	EditIndex: number;
	Task_Item_Data_search_Tasknew: Task_Item[];
	Task_Item_Temp: Task_Item = new Task_Item();
	Task_ItemN_Temp: Task_Item = new Task_Item();
	Task_Item_Data_search: Task_Item[];
	Task_Item_Data: Task_Item[];
	Task_Status_Id_: number = 0;
	Task_Item_Id_: number = 0;
	Historydiv: boolean = false;
	Pointer_Start_: number;
	Pointer_Stop_: number;
	Total_Task_Rows: number = 0;
	Task_Group_Id: number;
	Cas_FollowupTasknew_View: boolean = false;
	Tasknew_View: boolean = false;
	Tasknewmodal_View: boolean = true;
	Login_Department:number
	Login_Department_Name:string
	Add_Document_view: boolean = false;
	Date_value: string;
	User_Id_Temp:number;
	ToDate:Date;
	FromDate:Date;
	if_total:number;
	if_total1:number=0;
	if_complete:number;

	City: string;
	County: string;
	District: string;
	Suburb: string;

	Time_Change: number;
	ToDateString:string;
	FromDateString:string;
	TodayString:string;
	date_time: number;
	uid:number;
	User_Type:number;
	file_b2b_changed: boolean=false;
	Page_Check:number=0;
	view_page:number=0;
	Interview_Status_Data: Interview_Status[];
	Employer_Id_localStorage: string = "";
	Employee_Details_Data: Student_Task[];
	Employee_Details_ = new Student_Task();
	Time_Checking:number=0;
	job_dashboard_view:number=0;
	Pending_Type:number=0;
	constructor(
		public Student_Service_: Student_Service,
		private http: HttpClient,
		public Internship_Service_: Internship_Service,
		private route: ActivatedRoute,
		private router: Router,
		public dialogBox: MatDialog,
		private sanitizer: DomSanitizer,public Job_Category_Service_: Job_Category_Service,
	) {
		this.socket = io(this.url, { transports: ["websocket"] });
		this.socket = io(this.url);
	}
	ngOnInit() {
		debugger
		this.Login_User = localStorage.getItem("Login_User");
		this.view_page = Number(localStorage.getItem("view_page"))

		localStorage.setItem('view_page','0');
		this.Page_Check = Number(localStorage.getItem("Page_Check"))

    localStorage.setItem('Page_Check','0');
		this.Login_User_Name = localStorage.getItem("uname");
		this.Login_Department_Name= localStorage.getItem("Login_Department_Name");
		this.Login_Department = Number(localStorage.getItem("Login_Department"));
		this.User_Type = Number(localStorage.getItem("User_Type"));
		this.Date_value = localStorage.getItem("Look_In_");
		localStorage.setItem('Look_In_','0');
		this.User_Id_Temp= Number(localStorage.getItem("User_Search"));
		this.FromDate = new Date(localStorage.getItem('Search_FromDate'))
		this.ToDate = new Date(localStorage.getItem('Search_ToDate'));
		this.Time_Checking = Number(localStorage.getItem('Time_Checking'));
		this.Pending_Type = Number(localStorage.getItem("Pending_Type"));
		localStorage.removeItem('Pending_Type');
		localStorage.setItem('Time_Checking','0');
		this.Employer_Id_localStorage = localStorage.getItem("Student_Task_Id");
		this.job_dashboard_view = Number(localStorage.getItem("job_dashboard"));

		if(this.job_dashboard_view>0)
    {
        localStorage.removeItem('job_dashboard');
    }
    



		// localStorage.setItem('Student_Task_Id','0');
		// this.Employer_Id_localStorage = "2";


		if(Number(this.Employer_Id_localStorage)>0)
		{

			this.Get_Lead_Load_Data_ByUser(this.Login_User);
			this.Get_Employee_Details(Number(this.Employer_Id_localStorage));
		}
		// this.City = localStorage.getItem("city");
		// this.County = localStorage.getItem("county");
		// this.District = localStorage.getItem("state_district");
		// this.Suburb = localStorage.getItem("suburb");
		;
		this.if_total = Number(localStorage.getItem("if_total"));
		this.if_complete = Number(localStorage.getItem("if_complete"));

		;
		this.Time_Change = Number(localStorage.getItem("Time_Change"));
		this.ToDateString = this.ToDate.toString();
		this.FromDateString = this.FromDate.toString();
		this.TodayString = new Date().toString();
		this.date_time = Number(localStorage.getItem("date_time"));
	
		if (this.ToDateString !== this.TodayString && this.FromDateString !== this.TodayString)
		{
			localStorage.setItem("Time_Change", "0");
	
		}


		if (this.User_Id_Temp > 0) {
			this.User_Id_Temp = Number(this.User_Id_Temp);
			localStorage.setItem("User_Search", "0");
	
		}
		;

		if(this.date_time > 0 )
		{
			this.Date_value = "true";
			localStorage.setItem("date_time","0");
		}

		if (this.Date_value == "false" ) {
			// this.Look_In_Date = Number(this.Date_value);
			localStorage.setItem("Look_In_", "false");
	
		}

		if(this.if_total > 0) {
			this.if_total1 = Number(this.if_total);
			localStorage.setItem("if_total","0");
		}

		if(this.if_complete > 0){
			this.if_complete = Number(this.if_complete);
			localStorage.setItem("if_complete","0");
		}

		if (this.Employer_Id_localStorage > "0") {
			this.Student_Task_Id = Number(this.Employer_Id_localStorage);
			localStorage.setItem("Student_Task_Id", "0");
		}
	
		{
			
			this.Page_Load();
		
		}
	}
	Page_Load() {
		debugger
		this.Pointer_Start_ = 1;
		this.Pointer_Stop_ = this.Page_Length_;
		this.main_View = false;
		this.Summary_Div = true;
		this.Task_Item_Dropdown_All();
		this.Load_Dropdowns();
		// this.Task_Status_Dropdown();

if(this.Page_Check==2)

{
this.Add_CAS_Followup_Tasknew()
}
		
// if(this.view_page>0){
// 	debugger
// 	this.main_View = true;
// 	this.Summary_Div = false;
// 	this.Add_CAS_Followup_Tasknew();

// }


		// this.Employer_Status_Dropdown();
		this.Look_In_Date = false;
		 this.Get_Student_PageLoadData_Dropdowns()
		 this.Get_Employer_Source()
		//this.Get_Last_Followup();
		
		this.Show_FollowUp = false;
		this.Search_By_ = 1;
		this.Registered_By_ = 1;
		this.Get_Menu_Status(95, this.Login_User);
		this.Get_Menu_Status(38, this.Login_User);

		this.Get_Lead_Load_Data_ByUser(this.Login_User);
		this.Search_FromDate = this.New_Date(this.Search_FromDate);
		this.Search_ToDate = this.New_Date(this.Search_ToDate);
		this.Get_Time_Checking();

		this.myInnerHeight = window.innerHeight;
		this.myTotalHeight = this.myInnerHeight;
		this.myTotalHeight = this.myTotalHeight - 90;
		this.myInnerHeight = this.myInnerHeight - 280;
		// this.Search_Lead_button();


		if(this.view_page > 0)
		{
			this.Add_CAS_Followup_Tasknew()

		}
		// else
		// {
		// 	this.Tasknew_View = false;
		// this.Tasknewmodal_View = false;
		// this.Cas_FollowupTasknew_View = true;	
		// this.main_View = false	
		
		// }
	}
	Get_Employer_Source(){
		debugger
		this.Student_Service_.Get_Employer_Source().subscribe(	(Rows) => {
			debugger
			this.Employer_Source_Data = Rows[0].slice();			
			this.Employer_Source_Temp.Employer_Source_Id=0;
			this.Employer_Source_Temp.Employer_Source_Name="Select";
			this.Employer_Source_Data.unshift(Object.assign({}, this.Employer_Source_Temp));				
			this.Employer_Source_=this.Employer_Source_Data[0];
		})
	}
	Get_Time_Checking()
	{
		var tempdate = new Date();
		var tempdate2 = new Date();
		if(this.Time_Checking == 1)
		{
			;
			this.Search_FromDate = new Date(2023,0,20);
			tempdate.setDate(tempdate.getDate());
			this.Search_ToDate = tempdate;
			// this.Search_ToDate.setDate(this.Search_ToDate.getDate() - 1);
			return;
		}

		else if(this.Time_Checking == 2)
		{
			return;

		}
		
		else if(this.Time_Checking == 3 )
		{
			;
			tempdate.setDate(tempdate.getDate()+1);
			this.Search_FromDate = tempdate;
			tempdate2.setDate(tempdate2.getFullYear()+1);
			this.Search_ToDate = tempdate2;

			return;
		}
		
;
	}

	Get_Menu_Status(Menu_id, Login_user_id) {
		this.issLoading = false;
		this.Student_Service_.Get_Menu_Status(Menu_id, Login_user_id).subscribe(
			(Rows) => {
				// if(Menu_id==17)
				if (Rows[0][0] == undefined) {
					if (Menu_id == 156) {
						localStorage.removeItem("token");
						this.router.navigateByUrl("Home_Page");
					}
				}
				// if (Rows[0][0]!=undefined)
				else if (Rows[0][0].View > 0) {
					if (Menu_id == 156) {
						this.Permissions = Rows[0][0];
						if (this.Permissions == undefined || this.Permissions == null) {
							localStorage.removeItem("token");
							this.router.navigateByUrl("Home_Page");
						}
					}
				}
				if (Menu_id == 38) {
					this.Export_Permission = Rows[0][0];
					if (
						this.Export_Permission != undefined &&
						this.Export_Permission != null
					)
						this.Export_View = this.Export_Permission.View;
					else this.Export_View = true;
				}
				// else
				// {
				//     localStorage.removeItem('token');
				//                 this.router.navigateByUrl('Home_Page');
				// }
			},
			(Rows) => {
				this.issLoading = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	New_Date(Date_) {
		this.date = Date_;
		this.year = this.date.getFullYear();
		this.month = this.date.getMonth() + 1;
		if (this.month < 10) {
			this.month = "0" + this.month;
		}
		this.day = this.date.getDate().toString();
		if (Number.parseInt(this.day) < 10) {
			this.day = "0" + this.day;
		}
		this.date = this.year + "-" + this.month + "-" + this.day;
		return this.date;
	}
	Load_Dropdowns() {
		this.Internship_Service_.Get_Course_Load_Data().subscribe(
			(Rows) => {
				this.Enquiry_Source_Data = Rows[5].slice();
				this.Enquiry_Source_Temp.Enquiry_Source_Id = 0;
				this.Enquiry_Source_Temp.Enquiry_Source_Name = "Select";
				this.Enquiry_Source_Data.unshift(this.Enquiry_Source_Temp);
				this.Enquiry_Source_ = this.Enquiry_Source_Data[0];
				// this.Fees_Array = Rows[6].slice();
				// this.Fees_Temp.Fees_Id = 0;
				// this.Fees_Temp.Fees_Name = "Select";
				// this.Fees_Array.unshift(this.Fees_Temp);
				// this.Fees_Data_ = this.Fees_Array[0];
			},
			(Rows) => {
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	trackByFn(index, item) {
		return index;
	}
	Edit_Lead(Lead_Id, i) {
		localStorage.setItem("Student_Id", Lead_Id);

		this.Edit_Page_Permission = Get_Page_Permission(5);
		if (this.Edit_Page_Permission == undefined) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "No permission to view", Type: "2" },
			});
		} else if (this.Edit_Page_Permission.View == true)
			this.router.navigateByUrl("/Leads");
		else {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "No permission to view", Type: "2" },
			});
		}
	}
	Student_View_Click() {
		for (var i = 0; i < this.Student_Data_Search.length; i++) {
			if (this.Select_Student == false)
				this.Student_Data_Search[i].Check_Box_View = true;
			else this.Student_Data_Search[i].Check_Box_View = false;
		}
	}
	New_Followup() {
		this.Show_FollowUp = true;
		this.main_View = false;
		// this.FollowUp_.Next_FollowUp_Date=new Date();
		// this.FollowUp_.Next_FollowUp_Date=this.New_Date( this.FollowUp_.Next_FollowUp_Date);
	}
	Search_Lead_button() {
		debugger
		this.Pointer_Start_ = 1;
		this.Pointer_Stop_ = this.Page_Length_;
		this.Total_Task_Rows = 0;
		// this.Search_Student_Report();
		this.Search_Task_Data();
	}

	Search_More_Options() {
		if (this.More_Search_Options == true) this.More_Search_Options = false;
		else this.More_Search_Options = true;
	}
	Export() {
		this.Student_Service_.exportExcel(
			this.Student_Data_Search,
			"Receipt_Confirmation"
		);
	}
	Branch_Change() {
		this.FollowUp_Department_ = null;
		this.Followup_Users_ = null;
		this.FollowUp_Status_ = null;
		this.Followup_Department_Data = [];
		this.Followup_Department_Data_Check = [];
		this.Followup_Users_Data = [];
		this.Followup_Status_Data = [];

		// this.Followup_Users_ =null
this.Followup_Users_Task_ =null
// this.FollowUp_Department_Task_ =null
	}
	Focus_It() {
		setTimeout("$('[name=Followup_Status]').focus();", 0);
	}
	Department_Change() {
		//  document.getElementById("Followup_Status").focus();
		$("[name=Followup_Status]").focus();
		this.Focus_It();
		this.Followup_Users_ = null;
		this.FollowUp_Status_ = null;
		this.Followup_Users_Data = [];
		this.Followup_Users_Data_t=[];
		this.Followup_Status_Data = [];
		this.Followup_Department_Data = [];
		this.Followup_Users_Task_ = null;
		// if(this.FollowUp_Department_.Department_FollowUp==true)
		// this.Next_FollowUp_Date_Visible=false;
		// else
		// this.Next_FollowUp_Date_Visible=true;
		this.FollowUp_.Next_FollowUp_Date = new Date();
		this.FollowUp_.Next_FollowUp_Date = this.New_Date(
			this.FollowUp_.Next_FollowUp_Date
		);
	}
	Search_Task_Data() {
		debugger
		if(this.view_page == 0)
		{
		this.main_View = true;
		}
		this.Summary_Div = false;
		this.Load_Graph = 1;
		(this.Total_Amount = 0),
			(this.Total_Registration = 0),
			(this.Total_Students = 0);
		var User_Id = 0,
			look_In_Date_Value = 0,
			Status_Id = 0,
			Fees_Receipt_Status_Id = 0,
			Task_Item_Id = 0,
			User_Type = 0
			
debugger

		if (this.Look_In_Date == true) look_In_Date_Value = 1;

	
		if (this.User_Search != undefined && this.User_Search != null)
			if (
				this.User_Search.User_Details_Id != undefined &&
				this.User_Search.User_Details_Id != null
			)
				User_Id = this.User_Search.User_Details_Id;

		if (
			this.Task_Status_search_ != undefined &&
			this.Task_Status_search_ != null
		)
			if (
				this.Task_Status_search_.Task_Status_Id != undefined &&
				this.Task_Status_search_.Task_Status_Id != null
			)
				Status_Id = this.Task_Status_search_.Task_Status_Id;
		if (this.Task_Item_search_ != undefined && this.Task_Item_search_ != null)
			if (
				this.Task_Item_search_.Task_Item_Id != undefined &&
				this.Task_Item_search_.Task_Item_Id != null
			)
				Task_Item_Id = this.Task_Item_search_.Task_Item_Id;
		if (
			this.Search_Fees_Receipt_Status != undefined &&
			this.Search_Fees_Receipt_Status != null
		)
			if (
				this.Search_Fees_Receipt_Status.Fees_Receipt_Status_Id != undefined &&
				this.Search_Fees_Receipt_Status.Fees_Receipt_Status_Id != null
			)
				Fees_Receipt_Status_Id =
					this.Search_Fees_Receipt_Status.Fees_Receipt_Status_Id;
		var c = 0;

		if (this.User_Type !=undefined && this.User_Type !=null)
				{
					User_Type = this.User_Type;
				}
				

		this.issLoading = true;
		debugger
		this.Student_Service_.Search_Employer_Data(
			moment(this.Search_FromDate).format("YYYY-MM-DD"),
			moment(this.Search_ToDate).format("YYYY-MM-DD"),
			this.Login_User,
			look_In_Date_Value,
			Status_Id,
			Task_Item_Id,
			this.Pointer_Start_,
			this.Pointer_Stop_,
			this.Page_Length_,
			this.User_Id_Temp,
			this.if_total1,
			User_Type,
			this.Pending_Type
		).subscribe(
			(Graph_Status) => {
				debugger
				this.issLoading = false;
				this.Task_Data_Search = Graph_Status.returnvalue.Leads;
				var Serach_Data = Graph_Status.returnvalue.Leads;
				this.Total_Entries = Graph_Status.returnvalue.Leads[10].Student_Task_Id;
				// this.Task_Data_Search.length - 1;
					// this.Task_Data_Search[
					// 	this.Task_Data_Search.length - 1
					// ].Student_Task_Id;
				this.Task_Data_Search.pop();

				this.Temp_Date_Followup = new Date();
				var temp = this.New_Date(this.Temp_Date_Followup);
				debugger;
				for (var i = 0; i < this.Task_Data_Search.length; i++) {
					var temp_next = moment(
						this.Task_Data_Search[i].ActualFollowup_Date
					).format("YYYY-MM-DD");
					if (temp_next < temp) this.Task_Data_Search[i].tp = 2;
					else this.Task_Data_Search[i].tp = 1;

					this.Task_Data_Search[i].RowNo =
						this.Total_Task_Rows + this.Task_Data_Search.length - i;

					// this.Task_Data_Search[i].RowNo_sort = i + 1 + this.Total_Task_Rows;

					this.Task_Data_Search[i].RowNo =
						this.Total_Task_Rows+ i+1;
				}
				debugger;
				// this.Task_Data_Search = this.Task_Data_Search.sort(
				// 	(a, b) => b.RowNo_sort - a.RowNo_sort
				// );

				if (this.Task_Data_Search.length > 0)
					this.Total_Task_Rows =
						this.Total_Task_Rows + this.Task_Data_Search.length;

				// for (var j=0;j<Serach_Data.length;j++)
				// {
				//     this.Total_Amount=Number(this.Total_Amount)+Number(Serach_Data[j].ReceivedAmount)

				// }
				// for (var j=0;j<Serach_Data.length;j++)
				// {
				//     this.Total_Registration=Number(this.Total_Registration)+Number(Serach_Data[j].Registration)

				// }
				// for (var j=0;j<Serach_Data.length;j++)
				// {
				//     this.Total_Students=Number(this.Total_Students)+Number(Serach_Data[j].No_of_Students)

				// }

				// var Enquiry_Source_data_temp = Graph_Status.returnvalue.Leads;
				// this.issLoading = false;
				// var result = [];
				//  this.Enquiry_Source_columnNames=[];

				// for (var i in Enquiry_Source_data_temp)
				// {
				//     result.push([Enquiry_Source_data_temp[i].Enquiry_Source_Name, Enquiry_Source_data_temp[i].Data_Count]);

				// }

				// var data_temp = new google.visualization.DataTable(result);
				// this.Enquiry_Source_columnNames.push('User')
				// this.Enquiry_Source_columnNames.push('Count')
				// this.Enquiry_Source_data = result;
				// this.Data_Bar=result;
				if (Serach_Data.length == 0) {
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "No Data Found", Type: "3" },
					});
				}
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	Task_Status_Dropdown() {
		debugger
		this.issLoading = true;
		
		this.Student_Service_.Task_Status_Dropdown().subscribe(
			(Rows) => {
				debugger
				if (Rows != null) {
					this.Task_Status_Data_search = Rows[0];
					this.Task_Status_Temp_search.Task_Status_Id = 0;
					this.Task_Status_Temp_search.Status_Name = "Select";
					this.Task_Status_Data_search.unshift(this.Task_Status_Temp_search);
					// this.Task_Status_search_ = this.Task_Status_Data_search[0];
					this.Task_Status_ = Rows[0];




					
				// if(this.Time_Checking==1)
				// {
				// 	this.Task_Status_search_ = this.Task_Status_Data_search[1];
				// }
				// else
				// {
				// 	this.Task_Status_search_ = this.Task_Status_Data_search[0];
				// }
					
						
					this.issLoading = false;
					this.Search_Task_Data();
					// this.Search_Lead_button();
				}
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}
	

	// Employer_Status_Dropdown() {
	// 	
	// 	this.Student_Service_.Employer_Status_Dropdown().subscribe(
	// 		(Rows) => {
	// 			
	// 			this.Employer_Status_Data = Rows[0].slice();
	// 			this.Employer_Status_Temp.Employer_Status_Id = 0;
	// 			this.Employer_Status_Temp.Employer_Status_Name = "Select";
	// 			this.Employer_Status_Data.unshift(Object.assign({}, this.Employer_Status_Temp));
	// 			this.Employer_Status_ = this.Employer_Status_Data[0];

	// 		},
	// 		(Rows) => {
	// 			const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 				panelClass: "Dialogbox-Class",
	// 				data: { Message: "Error Occured", Type: "2" },
	// 			});
	// 		}
	// 	);
	// }
	Get_Student_PageLoadData_Dropdowns() {
		debugger
		this.Student_Service_.Get_Student_PageLoadData_Dropdowns().subscribe(
			(Rows) => {
				debugger
				this.Task_Status_Data = Rows[27].slice();
				this.Task_Status_Temp.Task_Status_Id = 0;
				this.Task_Status_Temp.Status_Name = "Select";
				this.Task_Status_Data.unshift(Object.assign({}, this.Task_Status_Temp));
				this.Task_Status_ = this.Task_Status_Data[0];




				
				this.Interview_Status_Data = Rows[28].slice();
				this.Interview_Status_Temp.Interview_Status_Id = 0;
				this.Interview_Status_Temp.Interview_Status_Name = "Select";
				this.Interview_Status_Data.unshift(Object.assign({}, this.Interview_Status_Temp));
				this.Interview_Status_ = this.Interview_Status_Data[0];
			},
			(Rows) => {
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	Task_Item_Dropdown_All() {
		this.issLoading = true;

		this.Student_Service_.Task_Item_Dropdown_All().subscribe(
			(Rows) => {
				if (Rows != null) {
					this.Task_Item_Data_search = Rows[0].slice();
					this.Task_Item_Data = Rows[0].slice();
					this.Task_Item_Temp.Task_Item_Id = 0;
					this.Task_Item_Temp.Task_Item_Name = "All";
					this.Task_ItemN_Temp.Task_Item_Id=0
					this.Task_ItemN_Temp.Task_Item_Name = "Select"
					this.Task_Item_Data_search.unshift(Object.assign({}, this.Task_Item_Temp));
					this.Task_Item_search_ = this.Task_Item_Data_search[0];
					this.Task_Item_Data.unshift(Object.assign({},this.Task_ItemN_Temp) );
					this.Task_Item_search_Tasknew_ = this.Task_Item_Data[0]
					this.issLoading = false;
					// if(this.Task_Item_Id_ >0)
					// {
					//     for (var i = 0; i < this.Task_Item_Data_search.length; i++) {
					//         if (
					//             this.Task_Item_Data_search[i].Task_Item_Id == this.Task_Item_Id_
					//         )
					//             this.Task_Item_ = this.Task_Item_Data_search[i];
					//     }
					// }
					// else
					//     this.Task_Item_ = this.Task_Item_Data_search[1];
					this.Search_Task_Data()
				}
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}
	Search_Student_Report() {
		this.main_View = true;
		this.Summary_Div = false;
		var value = 1,
			dept_id = 0,
			User_Id = 0,
			search_name_ = "0",
			look_In_Date_Value = 0,
			Enqury_Id = 0,
			branch_id = 0;
		if (this.Search_By_ != undefined && this.Search_By_ != null)
			if (
				this.Search_By_ != undefined &&
				this.Search_By_ != null &&
				this.Search_By_ != ""
			)
				value = this.Search_By_;

		if (this.Look_In_Date == true) look_In_Date_Value = 1;

		if (
			this.Search_Name != undefined &&
			this.Search_Name != null &&
			this.Search_Name != ""
		)
			search_name_ = this.Search_Name;

		if (this.User_Search != undefined && this.User_Search != null)
			if (
				this.User_Search.User_Details_Id != undefined &&
				this.User_Search.User_Details_Id != null
			)
				User_Id = this.User_Search.User_Details_Id;

		if (this.Department_Search != undefined && this.Department_Search != null)
			if (
				this.Department_Search.Department_Id != undefined &&
				this.Department_Search.Department_Id != null
			)
				dept_id = this.Department_Search.Department_Id;

		if (
			this.Enquiry_Source_Search_ != undefined &&
			this.Enquiry_Source_Search_ != null
		)
			if (
				this.Enquiry_Source_Search_.Enquiry_Source_Id != undefined &&
				this.Enquiry_Source_Search_.Enquiry_Source_Id != null
			)
				Enqury_Id = this.Enquiry_Source_Search_.Enquiry_Source_Id;

		if (this.Search_Branch != undefined && this.Search_Branch != null)
			if (
				this.Search_Branch.Branch_Id != undefined &&
				this.Search_Branch.Branch_Id != null
			)
				branch_id = this.Search_Branch.Branch_Id;

		this.issLoading = true;

		this.Student_Service_.Search_Enquiry_Source_Report(
			moment(this.Search_FromDate).format("YYYY-MM-DD"),
			moment(this.Search_ToDate).format("YYYY-MM-DD"),
			look_In_Date_Value,
			branch_id
		).subscribe(
			(Rows) => {
				//log(Rows)
				this.Student_Data_Search = Rows.returnvalue.Leads;
				this.missedfollowup_count = 0;
				this.followup_count = 0;

				for (var i = 0; i < this.Student_Data_Search.length; i++) {
					this.Student_Data_Search[i].RowNo = i + 1 + this.Total_Rows;
					if (this.Student_Data_Search[i].tp == 1)
						this.followup_count = this.followup_count + 1;
					if (this.Student_Data_Search[i].tp == 2)
						this.missedfollowup_count = this.missedfollowup_count + 1;
				}

				if (this.Student_Data_Search.length > 0)
					this.Total_Rows = this.Total_Rows + this.Student_Data_Search.length;
				this.issLoading = false;
				if (this.Student_Data_Search.length == 0) {
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "No Details Found", Type: "3" },
					});
				}
			},
			(Rows) => {
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
				this.issLoading = false;
			}
		);
	}
	Get_Lead_Load_Data() {
		this.issLoading = true;
		this.Student_Service_.Get_Lead_Load_Data().subscribe(
			(Rows) => {
				if (Rows != undefined) {
					this.issLoading = false;
					this.Department_Data = Rows.returnvalue.Department;
					this.Users_Data = Rows.returnvalue.Users;
					this.Branch_Data = Rows.returnvalue.Branch;
					this.Status_Data = Rows.returnvalue.Department_Status;

					this.Department_Temp.Department_Id = 0;
					this.Department_Temp.Department_Name = "All";
					this.Department_Data.unshift(Object.assign({}, this.Department_Temp));
					this.Department_Search = this.Department_Data[0];

					this.Users_Temp.User_Details_Id = 0;
					this.Users_Temp.User_Details_Name = "All";
					this.Users_Data.unshift(Object.assign({}, this.Users_Temp));
					this.User_Search = this.Users_Data[0];
					this.Branch_Temp1.Branch_Id = 0;

					this.Branch_Temp1.Branch_Name = "All";
					this.Branch_Data.unshift(this.Branch_Temp1);
					this.Search_Branch = this.Branch_Data[0];

					this.Status_Temp.Department_Status_Id = 0;
					this.Status_Temp.Department_Status_Name = "All";
					this.Status_Data.unshift(Object.assign({}, this.Status_Temp));
					this.Status_Search = this.Status_Data[0];
				}
			},
			(Rows) => {
				this.issLoading = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	Get_Lead_Load_Data_ByUser(Login_User) {
		debugger
		// this.issLoading = true;
		// this.Student_Service_.Get_Lead_Load_Data_ByUser(Login_User).subscribe(
		// 	(Rows) => {
		// 		this.Department_Data = Rows[1].slice();
		// 		this.Department_Temp.Department_Id = 0;
		// 		this.Department_Temp.Department_Name = "All";
		// 		this.Department_Data.unshift(this.Department_Temp);
		// 		this.Department_Search = this.Department_Data[0];

		// 		this.Users_Data = Rows[0].slice();
		// 		this.Users_Temp.User_Details_Id = 0;
		// 		this.Users_Temp.User_Details_Name = "All";
		// 		this.Users_Data.unshift(this.Users_Temp);
		// 		this.User_Search = this.Users_Data[0];

		// 		this.Branch_Data = Rows[2].slice();
		// 		this.Branch_Temp1.Branch_Id = 0;
		// 		this.Branch_Temp1.Branch_Name = "All";
		// 		this.Branch_Data.unshift(this.Branch_Temp1);
		// 		this.Search_Branch = this.Branch_Data[0];

		// 		this.Status_Data = Rows[5].slice();
		// 		this.Status_Temp.Department_Status_Id = 0;
		// 		this.Status_Temp.Department_Status_Name = "All";
		// 		this.Status_Data.unshift(this.Status_Temp);
		// 		this.Status_Search = this.Status_Data[0];

		// 		this.Fees_Receipt_Status_Data = Rows[8].slice();
		// 		this.Fees_Receipt_Status_Temp.Fees_Receipt_Status_Id = 0;
		// 		this.Fees_Receipt_Status_Temp.Fees_Receipt_Status_Name = "All";
		// 		this.Fees_Receipt_Status_Data.unshift(this.Fees_Receipt_Status_Temp);
		// 		this.Search_Fees_Receipt_Status = this.Fees_Receipt_Status_Data[0];

				
		// 	},
		// 	(Rows) => {
		// 		const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 			panelClass: "Dialogbox-Class",
		// 			data: { Message: "Error Occured", Type: "2" },
		// 		});
		// 	}
		// );

		if(this.Date_value=="false")
				{
				  this.Look_In_Date=false
				
				}
				
			debugger
				if(this.Date_value=="true")
				{
					this.Look_In_Date=true;
					localStorage.setItem("Look_In_", "false");
			
				}
			

			
			if(this.Time_Change > 0)
			 {
				 this.Search_FromDate =this.FromDate;
				 this.Search_ToDate = this.ToDate;
			 }

				
			 
							 if(this.User_Id_Temp!=0)
							   {
								 
								 for (var i = 0; i < this.Users_Data.length; i++) 
								 {
									 if (this.User_Id_Temp == this.Users_Data[i].User_Details_Id)
											 this.User_Search = this.Users_Data[i];
											   }
											   
								 }
								

							
								 if(this.if_complete!=0)
								 {
									
									for (var i=0;i<this.Task_Status_Data_search.length;i++)
									{
										if(this.if_complete == this.Task_Status_Data_search[i].Task_Status_Id)
										this.Task_Status_search_ = this.Task_Status_Data_search[i];
									}
								 }

						
			 
								//  const Employer_Id_localStorage = Number(this.Employer_Id_localStorage);
								//  if (Employer_Id_localStorage > 0) {
								// 	 this.Edit_Employer({ Student_Task_Id: Employer_Id_localStorage }, 1);
								debugger				//  }
								 
				if (this.Employer_Id_localStorage > "0") {
					// this.Edit_Employer({ Student_Task_Id: this.Employer_Id_localStorage }, 1);
					this.Get_Employee_Details(Number(this.Employer_Id_localStorage))
				}
							//  this.Search_Task_Data();
	}


	Get_Employee_Details(Student_Task_Id) {
		debugger
		//  this.Clr_ApplicationDetails();
		this.issLoading = true;

		this.Student_Service_.Get_Employee_Details(Student_Task_Id).subscribe(
			(Rows) => {

				debugger
				this.Employee_Details_Data = Rows[0];
				this.Employee_Details_ =this.Employee_Details_Data[0] 
				// this.Edit_Employer({ Student_Task_Id: this.Employee_Details_Data }, 1);

				this.Cas_Followup_ = Object.assign({}, this.Employee_Details_);

				
			if (this.Cas_Followup_.Followup_Date == null) {
				this.Cas_Followup_.Followup_Date = new Date();
				this.Cas_Followup_.Followup_Date = this.New_Date(
					this.Cas_Followup_.Followup_Date
				);
			} else
				this.Cas_Followup_.Followup_Date = this.New_Date(
					new Date(moment(this.Cas_Followup_.ActualFollowup_Date).format("YYYY-MM-DD"))
				);

		this.Department_1_Temp_.Department_Id = this.Cas_Followup_.Department_Id;
		this.Department_1_Temp_.Department_Name = this.Cas_Followup_.Department_Name;
		this.FollowUp_Department_Task_ = Object.assign({}, this.Department_1_Temp_);


		this.Followup_Users_1_Temp_.User_Details_Id = this.Cas_Followup_.To_User;
		this.Followup_Users_1_Temp_.User_Details_Name = this.Cas_Followup_.To_User_Name;
		this.Followup_Users_Task_ = Object.assign({}, this.Followup_Users_1_Temp_);
				
		for (var i = 0; i < this.Task_Item_Data.length; i++) {
			if (
				this.Cas_Followup_.Task_Item_Id ==
				this.Task_Item_Data[i].Task_Item_Id
			)
				this.Task_Item_search_Tasknew_ = this.Task_Item_Data[i];
		}


		for (var i = 0; i < this.Task_Status_Data.length; i++) {
			if (
				this.Cas_Followup_.Task_Status ==
				this.Task_Status_Data[i].Task_Status_Id
			)
				this.Task_Status_ = this.Task_Status_Data[i];
		}
        for (var i = 0; i < this.Employer_Status_Data.length; i++) {
			if (
				this.Cas_Followup_.Employer_Status_Id ==
				this.Employer_Status_Data[i].Employer_Status_Id
			)
				this.Employer_Status_ = this.Employer_Status_Data[i];
		}
this.Clr_cas_Followup();
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}
	
	Next_Click() {
		if (this.Task_Data_Search.length == this.Page_Length_) {
			this.Pointer_Start_ = this.Pointer_Start_ + this.Page_Length_;
			this.Pointer_Stop_ = this.Pointer_Stop_ + this.Page_Length_;
			this.nextflag = 1;
			if (this.Task_Data_Search.length > 0) {
				this.Search_Task_Data();
			}
		} else {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "No Other Details", Type: "3" },
			});
		}
	}

	previous_Click() {
		if (this.Pointer_Start_ > 1) {
			this.Pointer_Start_ = this.Pointer_Start_ - this.Page_Length_;
			this.Pointer_Stop_ = this.Pointer_Stop_ - this.Page_Length_;
		}
		this.Total_Task_Rows =
			this.Total_Task_Rows - this.Task_Data_Search.length - this.Page_Length_;
		if (this.Total_Task_Rows < 0) {
			this.Total_Task_Rows = 0;
		}
		this.Search_Task_Data();
	}
	// Search_Branch_Typeahead(event: any) {
	// 	var Value = "";
	// 	if (this.Followup_Branch_Data == undefined) this.Followup_Branch_Data = [];
	// 	if (this.Followup_Branch_Data.length == 0) {
	// 		if (event.target.value == "") Value = undefined;
	// 		else Value = event.target.value;

	// 		if (
	// 			this.Followup_Branch_Data == undefined ||
	// 			this.Followup_Branch_Data.length == 0
	// 		) {
	// 			this.issLoading = true;
	// 			this.Student_Service_.Search_Branch_Typeahead("").subscribe(
	// 				(Rows) => {
	// 					if (Rows != null) {
	// 						this.Followup_Branch_Data = Rows[0];
	// 						this.issLoading = false;
	// 					}
	// 				},
	// 				(Rows) => {
	// 					this.issLoading = false;
	// 				}
	// 			);
	// 		}
	// 	}
	// }


	Search_Branch_Typeahead(event: any,source:number) {
		// if (this.Followup_Branch_Data == undefined)
		// this.Followup_Branch_Data = [];
		// if (this.Followup_Branch_Data.length == 0) {
			var Value = "";
			if (event.target.value == "") Value = "";
			else Value = event.target.value.toLowerCase();

		if (
			this.Followup_Branch_Data == undefined ||
			this.Followup_Branch_Data.length == 0
		) {
			this.issLoading = true;
			this.Student_Service_.Search_Branch_Typeahead_Employer("").subscribe(
				(Rows) => {
					if (Rows != null) {
						this.Followup_Branch_Data = Rows[0];
						this.Followup_Branch_Data_Filter = []
						if(source==1){
							for (var i = 0; i < this.Followup_Branch_Data.length; i++) {
								if (
									this.Followup_Branch_Data[i].Branch_Name.toLowerCase().includes(
										Value
									)
								)
									this.Followup_Branch_Data_Filter.push(
										this.Followup_Branch_Data[i]
									);
							}
						}else{
							this.Followup_Branch_Data_Filter = Rows[0];
						}
						
						this.issLoading = false;
					}
				},
				(Rows) => {
					this.issLoading = false;
					// const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
				}
			);
		}else {
			if(source==1){
				this.Followup_Branch_Data_Filter = [];
				for (var i = 0; i < this.Followup_Branch_Data.length; i++) {
					if (
						this.Followup_Branch_Data[i].Branch_Name.toLowerCase().includes(Value)
					)
						this.Followup_Branch_Data_Filter.push(this.Followup_Branch_Data[i]);
				}
			}else{
				this.Followup_Branch_Data_Filter = [];
				for (var i = 0; i < this.Followup_Branch_Data.length; i++) {					
						this.Followup_Branch_Data_Filter.push(this.Followup_Branch_Data[i]);
				}
			}
			
		}
		// }
	}


	// Search_Branch_Typeahead(event: any,source:number) {
	// 	// if (this.Followup_Branch_Data == undefined)
	// 	// this.Followup_Branch_Data = [];
	// 	// if (this.Followup_Branch_Data.length == 0) {
	// 		var Value = "";
	// 		if (event.target.value == "") Value = "";
	// 		else Value = event.target.value.toLowerCase();

	// 	if (
	// 		this.Followup_Branch_Data == undefined ||
	// 		this.Followup_Branch_Data.length == 0
	// 	) {
	// 		this.issLoading = true;
	// 		this.Student_Service_.Search_Branch_Typeahead("").subscribe(
	// 			(Rows) => {
	// 				if (Rows != null) {
	// 					this.Followup_Branch_Data = Rows[0];
	// 					this.Followup_Branch_Data_Filter = []
	// 					if(source==1){
	// 						for (var i = 0; i < this.Followup_Branch_Data.length; i++) {
	// 							if (
	// 								this.Followup_Branch_Data[i].Branch_Name.toLowerCase().includes(
	// 									Value
	// 								)
	// 							)
	// 								this.Followup_Branch_Data_Filter.push(
	// 									this.Followup_Branch_Data[i]
	// 								);
	// 						}
	// 					}else{
	// 						this.Followup_Branch_Data_Filter = Rows[0];
	// 					}
						
	// 					this.issLoading = false;
	// 				}
	// 			},
	// 			(Rows) => {
	// 				this.issLoading = false;
	// 				// const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
	// 			}
	// 		);
	// 	}else {
	// 		if(source==1){
	// 			this.Followup_Branch_Data_Filter = [];
	// 			for (var i = 0; i < this.Followup_Branch_Data.length; i++) {
	// 				if (
	// 					this.Followup_Branch_Data[i].Branch_Name.toLowerCase().includes(Value)
	// 				)
	// 					this.Followup_Branch_Data_Filter.push(this.Followup_Branch_Data[i]);
	// 			}
	// 		}else{
	// 			this.Followup_Branch_Data_Filter = [];
	// 			for (var i = 0; i < this.Followup_Branch_Data.length; i++) {					
	// 					this.Followup_Branch_Data_Filter.push(this.Followup_Branch_Data[i]);
	// 			}
	// 		}
			
	// 	}
	// 	// }
	// }

	display_Branch(Branch_: Branch) {
		if (Branch_) {
			return Branch_.Branch_Name;
		}
	}
	Search_Branch_Department_Typeahead(event: any) {
		var Value = "";
		if (event.target.value == "") Value = undefined;
		else Value = event.target.value;

		if (
			this.FollowUp_Branch_ == null ||
			this.FollowUp_Branch_.Branch_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Select Branch", Type: "3" },
			});
		} else {
			if (
				this.Followup_Department_Data == undefined ||
				this.Followup_Department_Data.length == 0
			) {
				if (
					this.Followup_Department_Data_Check == undefined ||
					this.Followup_Department_Data_Check.length == 0
				) {
					this.issLoading = true;
					this.Student_Service_.Search_Branch_Department_Employer_Typeahead(
						this.FollowUp_Branch_.Branch_Id,
						""
					).subscribe(
						(Rows) => {
							if (Rows != null) {
								// if(Rows.code!=undefined)
								// {
								//     const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.Code,Type:"false"}});
								// }
								this.Followup_Department_Data = Rows[0];
								this.Followup_Department_Data_Check = Rows[0];
								this.issLoading = false;
							}
						},
						(Rows) => {
							this.issLoading = false;
							const dialogRef = this.dialogBox.open(DialogBox_Component, {
								panelClass: "Dialogbox-Class",
								data: { Message: "Error Occured", Type: "2" },
							});
						}
					);
				} else {
					this.Followup_Department_Data = this.Followup_Department_Data_Check;
				}
			}
		}
	}
	display_Department(Department_: Department) {
		if (Department_) {
			return Department_.Department_Name;
		}
	}
	Search_Department_Status_Typeahead(event: any) {
		var Value = "";
		if (event.target.value == "") Value = undefined;
		else Value = event.target.value;

		if (
			this.FollowUp_Department_ == null ||
			this.FollowUp_Department_.Department_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Error Occured", Type: "2" },
			});
		} else {
			if (
				this.Followup_Status_Data == undefined ||
				this.Followup_Status_Data.length == 0
			) {
				this.issLoading = true;
				this.Student_Service_.Search_Department_Status_Typeahead(
					this.FollowUp_Department_.Department_Id,
					""
				).subscribe(
					(Rows) => {
						if (Rows != null) {
							this.Followup_Status_Data = Rows[0];
							this.issLoading = false;
						}
					},
					(Rows) => {
						this.issLoading = false;
					}
				);
			}
		}
	}
	display_Followup_Status(Status_: Department_Status) {
		if (Status_) {
			return Status_.Department_Status_Name;
		}
	}
	Search_Department_User_Typeahead(event: any) {
		var Value = "";
		if (event.target.value == "") Value = undefined;
		else Value = event.target.value;

		if (
			this.FollowUp_Department_ == null ||
			this.FollowUp_Department_.Department_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Error Occured", Type: "3" },
			});
		} else {
			if (
				this.Followup_Users_Data == undefined ||
				this.Followup_Users_Data.length == 0
			) {
				this.issLoading = true;
				this.Student_Service_.Search_Department_User_Typeahead(
					this.FollowUp_Branch_.Branch_Id,
					this.FollowUp_Department_.Department_Id,
					""
				).subscribe(
					(Rows) => {
						if (Rows != null) {
							this.Followup_Users_Data = Rows[0];
							this.issLoading = false;
						}
					},
					(Rows) => {
						this.issLoading = false;
						// const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
					}
				);
			}
		}
	}

	Search_User_Typeahead(event: any)
	{ 
    	var Value = "";
    	if (event.target.value == "")
    		Value = undefined;
    	else
    		Value = event.target.value;
    	this.issLoading=true;

		this.Student_Service_.Search_User_Typeahead(Value).subscribe(Rows => 
			{
           
				if (Rows != null) 
				{
					this.Users_Data = Rows[0];
				}

		this.issLoading=false;
			},
		Rows => 
			{
    			this.issLoading=false;
				const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
			}
			);


}

	display_Followup_Users(Users_: User_Details) {
		if (Users_) {
			return Users_.User_Details_Name;
		}
	}
	Remarks_Typeahead(event: any) {
		var Value = "";
		if (event.target.value == "") Value = undefined;
		else Value = event.target.value;
		this.issLoading = true;

		this.Student_Service_.Remarks_Typeahead(Value).subscribe(
			(Rows) => {
				if (Rows != null) {
					this.Remarks_Data = Rows[0];
				}
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}
	display_Remarks(Remarks_e: Remarks) {
		if (Remarks_e) {
			return Remarks_e.Remarks_Name;
		}
	}
	Save_Student_Report_FollowUp() {
		if (
			this.FollowUp_Branch_ == null ||
			this.FollowUp_Branch_.Branch_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Branch", Type: "3" },
			});
			return;
		}
		if (
			this.FollowUp_Department_ == null ||
			this.FollowUp_Department_.Department_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Department", Type: "3" },
			});
			return;
		}
		if (
			this.FollowUp_Status_ == null ||
			this.FollowUp_Status_.Department_Status_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Status", Type: "3" },
			});
			return;
		}
		if (
			this.Followup_Users_ == null ||
			this.Followup_Users_.User_Details_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter User", Type: "3" },
			});
			return;
		}
		if (this.FollowUp_.Next_FollowUp_Date == undefined) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Choose Date", Type: "3" },
			});
			return;
		}
		this.Student_.Branch = this.FollowUp_Branch_.Branch_Id;
		this.Student_.Department = this.FollowUp_Department_.Department_Id;
		this.Student_.Status = this.FollowUp_Status_.Department_Status_Id;
		this.Student_.Next_FollowUp_Date = this.New_Date(
			new Date(moment(this.FollowUp_.Next_FollowUp_Date).format("YYYY-MM-DD"))
		);
		this.Student_.User_Id = this.Followup_Users_.User_Details_Id;
		this.Student_.By_User_Id = parseInt(this.Login_User);
		var Student_Deatils = [];
		for (var m = 0; m < this.Student_Data_Search.length; m++) {
			if (Boolean(this.Student_Data_Search[m].Check_Box_View) == true) {
				//this.Student_Selection_Data_Temp.push(this.Student_Data[m]);
				Student_Deatils.push({
					Student_Id: this.Student_Data_Search[m].Student_Id,
				});
			}
		}
		this.Student_.Student_Selected_Details = Student_Deatils;
		if (Student_Deatils.length == 0) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Please Select Student", Type: "2" },
			});
			this.Close_Click();
		}
		document.getElementById("Save_Button").hidden = true;
		this.issLoading = true;
		this.Student_Service_.Save_Student_Report_FollowUp(this.Student_).subscribe(
			(Save_status) => {
				this.issLoading = false;
				// log(Save_status[0][0])
				if (Number(Save_status[0][0].Student_Id_) > 0) {
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Saved", Type: "false" },
					});
					this.Close_Click();
					document.getElementById("Save_Button").hidden = false;
				} else {
					this.issLoading = false;
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Error Occured", Type: "2" },
					});
					document.getElementById("Save_Button").hidden = false;
				}
			},
			(Rows) => {
				this.issLoading = false;
				document.getElementById("Save_Button").hidden = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: "Error Occured", Type: "2" },
				});
			}
		);
	}
	Close_Click() {
		;
		this.Show_FollowUp = false;
		this.main_View = true;
		this.Select_Student = false;
		this.Select_View = false;
		this.FollowUp_Branch_ = null;
		this.FollowUp_Department_ = null;
		this.FollowUp_Status_ = null;
		this.Followup_Users_ = null;
		;
		this.Remarks_ = null;
		alert(this.Remarks_ = null);
		this.Student_.Next_FollowUp_Date = null;
	}
	Lead_Refund_Approve_Reject() {
		// this.ApplicationDetails_.Student_Id=this.Student_.Student_Id;
		if (
			this.Comment == undefined ||
			this.Comment == null ||
			this.Comment == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Comment", Type: "3" },
			});
			return;
		}
		const dialogRef = this.dialogBox.open(DialogBox_Component, {
			panelClass: "Dialogbox-Class",
			data: {
				Message: "Do you want to Continue ?",
				Type: true,
				Heading: "Confirm",
			},
		});

		dialogRef.afterClosed().subscribe((result) => {
			if (result == "Yes") {
				this.issLoading = true;
				this.Student_Service_.Lead_Refund_Approve_Reject(
					this.Lead_Fees_Receipt_Id,
					this.approve_reject_status,
					this.Comment,
					this.Login_User
				).subscribe(
					(Save_status) => {
						if (Number(Save_status[0][0].Fees_Receipt_Id_) > 0) {
							// this.Remove_Activte_Visiblility = false;
							// this.Activte_Visiblility = false;
							// if (
							// 	this.Remove_Activity_Permissions != undefined &&
							// 	this.Remove_Activity_Permissions != null
							// )
							// 	if (this.Remove_Activity_Permissions.View == true)
							// 		this.Remove_Activte_Visiblility = true;
							const dialogRef = this.dialogBox.open(DialogBox_Component, {
								panelClass: "Dialogbox-Class",
								data: { Message: "Saved", Type: "false" },
							});
							// this.Total_Rows = this.Total_Rows - this.Student_Data.length;
							// this.Search_Student();
							this.Refund_Approval_Comment_View = false;
							this.Search_Div = false;
							this.Search_Task_Data();
							this.Comment = "";
						} else {
							const dialogRef = this.dialogBox.open(DialogBox_Component, {
								panelClass: "Dialogbox-Class",
								data: { Message: "Error Occured", Type: "2" },
							});
						}
						this.issLoading = false;
					},
					(Rows) => {
						this.issLoading = false;
						const dialogRef = this.dialogBox.open(DialogBox_Component, {
							panelClass: "Dialogbox-Class",
							data: { Message: "Error Occured", Type: "2" },
						});
					}
				);
			}
		});
	}
	// Lead_Refund_Reject(Fees_Receipt_Id, index) {
	//     //    application_details_id_
	//     const dialogRef = this.dialogBox.open(DialogBox_Component, {
	//         panelClass: "Dialogbox-Class",
	//         data: {
	//             Message: "Do you want to Reject ?",
	//             Type: true,
	//             Heading: "Confirm",
	//         },
	//     });

	//     dialogRef.afterClosed().subscribe((result) => {
	//         if (result == "Yes") {
	//             this.issLoading = true;
	//             this.Student_Service_.Lead_Refund_Reject(Fees_Receipt_Id).subscribe(
	//                 (update_status) => {

	//                     if (update_status[0][0].Fees_Receipt_Id_ > 0) {
	//                         const dialogRef = this.dialogBox.open(DialogBox_Component, {
	//                             panelClass: "Dialogbox-Class",
	//                             data: { Message: "Team Lead Rejected", Type: "false" },
	//                         });
	//                         // this.Total_Rows = this.Total_Rows - this.Student_Data.length;
	//                         this.Search_Refund_Approval();

	//                     }

	//                     else {
	//                         this.issLoading = false;
	//                         const dialogRef = this.dialogBox.open(DialogBox_Component, {
	//                             panelClass: "Dialogbox-Class",
	//                             data: { Message: "Error Occured", Type: "2" },
	//                         });
	//                     }
	//                     this.issLoading = false;
	//                 },
	//                 (Rows) => {
	//                     this.issLoading = false;
	//                     const dialogRef = this.dialogBox.open(DialogBox_Component, {
	//                         panelClass: "Dialogbox-Class",
	//                         data: { Message: "Error Occured", Type: "2" },
	//                     });
	//                 }
	//             );
	//         }
	//     });
	// }
	Lead_Refund_Comment_View(Fees_Receipt_Id, status, index) {
		//    application_details_id_

		this.Refund_Approval_Comment_View = true;
		this.Search_Div = true;
		this.approve_reject_status = status;
		this.Lead_Fees_Receipt_Id = Fees_Receipt_Id;
	}
	Lead_Refund_Comment_close() {
		this.Search_Div = false;
		this.Refund_Approval_Comment_View = false;
		this.Comment = "";
	}
	Add_CAS_Followup(Student_Task_Id, Student_Id, task_item_id, task_group_id,employerName) {
		this.Cas_Followup_.Followup_Date = new Date();
		this.Cas_Followup_.Followup_Date = this.New_Date(
			this.Cas_Followup_.Followup_Date
			);
			this.Cas_Followup_.Employer_Name=employerName
			this.Cas_Followup_View = true; 
			this.main_View = false;
			this.cas_task_id = Student_Task_Id;
			this.cas_task_student_id = Student_Id;
			this.cas_task_item_id = task_item_id;
			this.cas_task_group_id = task_group_id;
			console.log('this.Cas_Followup_: ', this.Cas_Followup_);
	}
	Clr_cas_Followup() {
		this.Cas_Followup_.Remark = "";
		this.Cas_Followup_.Employer_Name = "";
		this.Job_Country_=0;
		this.Cas_Followup_.Mobile = "";
		this.Cas_Followup_.Land_Number="";
		this.Cas_Followup_.Email_Id = "";
		this.Cas_Followup_.Contact_Person_Name = "";
		this.Cas_Followup_.Address = "";
		this.Cas_Followup_.Country_Name = "";
		this.Cas_Followup_.Followp_Time = "";
		this.Cas_Followup_.Employer_Source = "";
		if (this.Interview_Status_Data != null && this.Interview_Status_Data != undefined)
		this.Interview_Status_ = this.Interview_Status_Data[0];
		this.Cas_Followup_.Followup_Date = new Date();
		this.Cas_Followup_.Followup_Date = this.New_Date(
			this.Cas_Followup_.Followup_Date
		);
		if (
			this.Task_Status_Data_search != null &&
			this.Task_Status_Data_search != undefined
		)
			this.Task_Status_search_ = this.Task_Status_Data_search[1];
		if (
			this.Task_Item_Data_search != null &&
			this.Task_Item_Data_search != undefined
		)
			this.Task_Item_search_ = this.Task_Item_Data_search[0];
	}
	// Save_Cas_Followup() {
	// 	if (
	// 		this.Task_Status_ == undefined ||
	// 		this.Task_Status_ == null ||
	// 		this.Task_Status_.Task_Status_Id == undefined ||
	// 		this.Task_Status_.Task_Status_Id == 0
	// 	) {
	// 		const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 			panelClass: "Dialogbox-Class",
	// 			data: { Message: "Select Status", Type: "3" },
	// 		});
	// 		return;
	// 	}

	// 	if (
	// 		this.Cas_Followup_.Remark == undefined ||
	// 		this.Cas_Followup_.Remark == null ||
	// 		this.Cas_Followup_.Remark == ""
	// 	) {
	// 		const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 			panelClass: "Dialogbox-Class",
	// 			data: { Message: "Enter Remark", Type: "3" },
	// 		});
	// 		return;
	// 	}
	// 	this.Cas_Followup_.Student_Id = this.cas_task_student_id;
	// 	this.Cas_Followup_.Task_Status = this.Task_Status_.Task_Status_Id;
	// 	this.Cas_Followup_.Status_Name = this.Task_Status_.Status_Name;
	// 	this.Cas_Followup_.To_User = Number(this.Login_User);
	// 	this.Cas_Followup_.To_User_Name = this.Login_User_Name;
	// 	this.Cas_Followup_.Student_Task_Id = this.cas_task_id;
	// 	this.Cas_Followup_.Task_Item_Id = this.cas_task_item_id;
	// 	this.Cas_Followup_.Task_Group_Id = this.cas_task_group_id;
	// 	this.Cas_Followup_.Followup_Date = this.New_Date(
	// 		new Date(moment(this.Cas_Followup_.Followup_Date).format("YYYY-MM-DD"))
	// 	);
	// 	if (this.Save_Call_Status == true) return;
	// 	else this.Save_Call_Status = true;
	// 	this.issLoading = true;
	// 	this.Student_Service_.Save_Cas_Followup(this.Cas_Followup_).subscribe(
	// 		(Save_work_experience) => {
	// 			Save_work_experience = Save_work_experience[0];
	// 			if (Number(Save_work_experience[0].Student_Task_Id_) > 0) {
	// 				this.Save_Call_Status = false;
	// 				const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 					panelClass: "Dialogbox-Class",
	// 					data: { Message: "Saved", Type: "false" },
	// 				});
	// 				// this.Get_WorkexperienceDetails(Save_work_experience[0].Student_Id_);
	// 				this.Clr_cas_Followup();
	// 				this.Close_Cas_Followup();
	// 				this.Search_Task_Data();
	// 			} else {
	// 				const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 					panelClass: "Dialogbox-Class",
	// 					data: { Message: "Error Occured", Type: "2" },
	// 				});
	// 			}
	// 			this.issLoading = false;
	// 		},
	// 		(Rows) => {
	// 			this.issLoading = false;
	// 			const dialogRef = this.dialogBox.open(DialogBox_Component, {
	// 				panelClass: "Dialogbox-Class",
	// 				data: { Message: Rows.error.error, Type: "2" },
	// 			});
	// 		}
	// 	);
	// }

	Save_Cas_Followup()
	{
		this.InitLocation(2)
	}

	Save_Cas_Followup_clk() {
		console.log('hi');
		
		if (
			this.Task_Status_ == undefined ||
			this.Task_Status_ == null ||
			this.Task_Status_.Task_Status_Id == undefined ||
			this.Task_Status_.Task_Status_Id == 0
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Select Status", Type: "3" },
			});
			return;
		}
		// if (
		//     this.Task_Item_search_ == undefined ||
		//     this.Task_Item_search_ == null ||
		//     this.Task_Item_search_.Task_Item_Id == undefined ||
		//     this.Task_Item_search_.Task_Item_Id == 0
		//     ) {
		//     const dialogRef = this.dialogBox.open(DialogBox_Component, {
		//     panelClass: "Dialogbox-Class",
		//     data: { Message: "Select Task", Type: "3" },
		//     });
		//     return;
		//     }
		if (
			this.Cas_Followup_.Remark == undefined ||
			this.Cas_Followup_.Remark == null ||
			this.Cas_Followup_.Remark == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Remark", Type: "3" },
			});
			return;
		}

		if (
			this.Cas_Followup_.Followup_Date == undefined ||
			this.Cas_Followup_.Followup_Date == null 
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Choose Followup Date", Type: "3" },
			});
			return;
		}

		this.Cas_Followup_.Student_Id = this.cas_task_student_id;
		this.Cas_Followup_.Task_Status = this.Task_Status_.Task_Status_Id;
		this.Cas_Followup_.Status_Name = this.Task_Status_.Status_Name;
		this.Cas_Followup_.To_User = Number(this.Login_User);
		this.Cas_Followup_.To_User_Name = this.Login_User_Name;
		this.Cas_Followup_.Branch_Id = this.FollowUp_Branch_Task_.Branch_Id;
		this.Cas_Followup_.Branch_Name = this.FollowUp_Branch_Task_.Branch_Name;
;
		this.Cas_Followup_.Student_Task_Id = this.cas_task_id;
		this.Cas_Followup_.Task_Item_Id = this.cas_task_item_id;
		this.Cas_Followup_.Task_Group_Id = this.cas_task_group_id;
		this.Cas_Followup_.Interview_Status = this.Interview_Status_.Interview_Status_Id;
		this.Cas_Followup_.Interview_Status_Name = this.Interview_Status_.Interview_Status_Name; // Include the name
this.Cas_Followup_.Employer_Status_Id = this.Employer_Status_.Employer_Status_Id;
this.Cas_Followup_.Employer_Status_Name = this.Employer_Status_.Employer_Status_Name;
		this.Cas_Followup_.By_User_Id = Number(this.Login_User);
		this.Cas_Followup_.By_User_Name = this.Login_User_Name;
	
		// this.Cas_Followup_.Followp_Time = this.cas_Followp_Time;
		this.Cas_Followup_.City = this.city;
		this.Cas_Followup_.Suburb = this.suburb;
		this.Cas_Followup_.District = this.state_district;
		this.Cas_Followup_.County = this.county;
console.log(this.Cas_Followup_)
		this.Cas_Followup_.Followup_Date = this.New_Date(
			
			new Date(moment(this.Cas_Followup_.Followup_Date).format("YYYY-MM-DD"))
		);
		if (this.Save_Call_Status == true) return;
		else this.Save_Call_Status = true;
		this.issLoading = true;
		
		this.Student_Service_.Save_Cas_Followup_Employer(this.Cas_Followup_).subscribe(
			(Save_work_experience) => {
				
				Save_work_experience = Save_work_experience[0];
				if (Number(Save_work_experience[0].Student_Task_Id_) > 0) {
					this.Save_Call_Status = false;
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Saved", Type: "false" },
					});
					// this.Get_WorkexperienceDetails(Save_work_experience[0].Student_Id_);
					this.Clr_cas_Followup();
					this.Close_Cas_Followup();
					this.Search_Lead_button();

					var notification_type_ = "Task";
					var message = {
						To_User: Save_work_experience[0].To_User_,
						Task_Count: Save_work_experience[0].Task_Count_,
						Notification_Type_Name: notification_type_,
					};
					this.socket.emit("new-message", message);
				} else {
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Error Occured", Type: "2" },
					});
				}
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: Rows.error.error, Type: "2" },
				});
			}
		);
	}
	Close_Cas_Followup() {
		this.Cas_Followup_View = false;
		this.main_View = true;
	}
	Task_History_Click(Student_Task_Id_, Student_Name, To_User_Name) {
		this.student_name = Student_Name;
		this.to_user_name = To_User_Name;
		this.Student_Task_Id = Student_Task_Id_;
		this.Historydiv = true;
		this.main_View = false;
		this.Get_Task_History(this.Student_Task_Id);
	}
	Close_History() {
		this.Historydiv = false;
		this.main_View = true;
	}
	Get_Task_History(Student_Task_Id) {
		//  this.Clr_ApplicationDetails();
		this.issLoading = true;

		this.Student_Service_.Get_Employer_History(Student_Task_Id).subscribe(
			(Rows) => {
				this.Student_Task_Data = Rows[0];
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
	}


	Get_Last_Followup() {
		if (
			this.FollowUp_.Branch == 0 ||
			this.FollowUp_.Branch == undefined ||
			this.FollowUp_.Branch == null
		) {
			this.issLoading = true;
			this.Student_Service_.Get_Last_Followup(this.Login_User).subscribe(
				(Save_status) => {
					
					Save_status = Save_status.returnvalue.FollowUp[0];
					if (Save_status != undefined) {
						this.issLoading = false;
						this.FollowUp_ = Save_status;
						this.Branch_Temp.Branch_Id = this.FollowUp_.Branch;
						this.Branch_Temp.Branch_Name = this.FollowUp_.Branch_Name;
						this.FollowUp_Branch_Task_ = Object.assign({}, this.Branch_Temp);

					}
					this.issLoading = false;
				},
				(Rows) => {
					this.issLoading = false;
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Error Occured", Type: "2" },
					});
				}
			);
		}
	}


	Add_CAS_Followup_Tasknew() {
		debugger
		this.Cas_Followup_.Followup_Date = new Date();
		this.Cas_Followup_.Followup_Date = this.New_Date(
			this.Cas_Followup_.Followup_Date
		);
		this.Task_Group_Id = 4;		
		this.Tasknew_View = false;
		this.Tasknewmodal_View = false;
		this.Cas_FollowupTasknew_View = true;	
		debugger;
		this.main_View = false	
		this.Clr_Tasknewcas_Followup();
	}
	Clr_Tasknewcas_Followup() {
		this.Cas_Followup_.Student_Task_Id = 0;
		this.Cas_Followup_.Remark = "";
		this.Cas_Followup_.Task_Details = "";
		this.Cas_Followup_.Task_Group_Id = 0;

		this.Job_Category_1_=null;


		this.Cas_Followup_.Employer_Name = "";

		this.Cas_Followup_.Mobile = "";
		this.Cas_Followup_.Land_Number="";
		this.Cas_Followup_.Email_Id = "";
		this.Cas_Followup_.Contact_Person_Name = "";
		this.Cas_Followup_.Address = "";
		this.Cas_Followup_.Followp_Time = "";
		this.Cas_Followup_.Employer_Source = "";
		this.Cas_Followup_.Country_Name = "";

		this.Cas_Followup_.Followup_Date = new Date();
		this.Cas_Followup_.Followup_Date = this.New_Date(
			this.Cas_Followup_.Followup_Date
		);

		if (this.Task_Status_Data != null && this.Task_Status_Data != undefined)
			this.Task_Status_ = this.Task_Status_Data[0];

		if (
			this.Task_Item_Data != null &&
			this.Task_Item_Data != undefined
		)
			this.Task_Item_search_Tasknew_ = this.Task_Item_Data[0];

		// this.FollowUp_Department_TN = null;
		// this.Followup_Users_tN = null;
		this.Followup_Users_tempN.User_Details_Id = Number(this.Login_User);
		this.Followup_Users_tempN.User_Details_Name = this.Login_User_Name
		this.Followup_Users_Task_= this.Followup_Users_tempN;

		this.FollowUp_Department_TempN.Department_Id = Number(this.Login_Department);
		this.FollowUp_Department_TempN.Department_Name = this.Login_Department_Name;
		this.FollowUp_Department_Task_ = this.FollowUp_Department_TempN;

		this.FollowUp_Branch_Task_ = Object.assign({}, this.Branch_Temp);
	}
	// Task_Item_Dropdown(Task_Group_Id) {
	// 	this.issLoading = true;
	// 	this.Student_Service_.Task_Item_Dropdown(Task_Group_Id).subscribe(
	// 		(Rows) => {
	// 			if (Rows != null) {
	// 				this.Task_Item_Data_search = Rows[0];
	// 				this.Task_Item_Temp.Task_Item_Id = 0;
	// 				this.Task_Item_Temp.Task_Item_Name = "Select";
	// 				this.Task_Item_Data_search.unshift(this.Task_Item_Temp);

	// 				this.Task_Item_ = this.Task_Item_Data_search[0];
	// 				this.Task_Item_search_ = this.Task_Item_Data_search[0];
	// 				this.Task_Item_search_Tasknew_ = this.Task_Item_Data_search[0];
	// 				this.issLoading = false;

	// 				if (this.Task_Item_Id_ > 0) {
	// 					for (var i = 0; i < this.Task_Item_Data_search.length; i++) {
	// 						if (
	// 							this.Task_Item_Data_search[i].Task_Item_Id == this.Task_Item_Id_
	// 						)
	// 							this.Task_Item_ = this.Task_Item_Data_search[i];
	// 					}
	// 				} else this.Task_Item_ = this.Task_Item_Data_search[1];

	// 				// this.Search_Task_Data()
	// 			}
	// 		},
	// 		(Rows) => {
	// 			this.issLoading = false;
	// 		}
	// 	);
	// }


	Edit_Employer(Branch_e:Student_Task,index)
    {

debugger
		this.Tasknew_View = false;
		this.Tasknewmodal_View = false;
		this.Cas_FollowupTasknew_View = true;	
		this.main_View = false	
		this.Student_Task_Id=Branch_e.Student_Task_Id;
		this.Cas_Followup_ = Object.assign({}, Branch_e);

		console.log('this.Cas_Followup_.Followup_Date: ', this.Cas_Followup_.Followup_Date);
		
if(this.Cas_Followup_.Job_Country=="United Kingdom"){this.Job_Country_ =1}
if(this.Cas_Followup_.Job_Country=="Ireland"){this.Job_Country_ =2}
if(this.Cas_Followup_.Job_Country=="Select"){this.Job_Country_ =0}
		// this.Cas_Followup_.Followup_Date = 
		// 	new Date(this.Cas_Followup_.Followup_Date);
			
			if (this.Cas_Followup_.Followup_Date == null) {
				this.Cas_Followup_.Followup_Date = new Date();
				this.Cas_Followup_.Followup_Date = this.New_Date(
					this.Cas_Followup_.Followup_Date
				);
			} else
				this.Cas_Followup_.Followup_Date = this.New_Date(
					new Date(moment(this.Cas_Followup_.ActualFollowup_Date).format("YYYY-MM-DD"))
				);
				this.Branch_Temp.Branch_Id = this.Cas_Followup_.Branch_Id;
				this.Branch_Temp.Branch_Name = this.Cas_Followup_.Branch_Name;
				this.FollowUp_Branch_Task_ = Object.assign({}, this.Branch_Temp);
				this.Cas_Followup_.Employer_Source==null?this.Cas_Followup_.Employer_Source='':''

		this.Department_1_Temp_.Department_Id = this.Cas_Followup_.Department_Id;
		this.Department_1_Temp_.Department_Name = this.Cas_Followup_.Department_Name;
		this.FollowUp_Department_Task_ = Object.assign({}, this.Department_1_Temp_);
;
		this.Followup_Users_1_Temp_.User_Details_Id = this.Cas_Followup_.To_User;
		this.Followup_Users_1_Temp_.User_Details_Name = this.Cas_Followup_.To_User_Name;
		this.Followup_Users_Task_ = Object.assign({}, this.Followup_Users_1_Temp_);

		this.Job_Category_1_Temp_.Job_Category_Id = this.Cas_Followup_.Job_Category_Id;
    this.Job_Category_1_Temp_.Job_Category_Name = this.Cas_Followup_.Job_Category_Name;
    this.Job_Category_1_ = Object.assign({}, this.Job_Category_1_Temp_);
		;
				
		for (var i = 0; i < this.Task_Item_Data.length; i++) {
			if (
				this.Cas_Followup_.Task_Item_Id ==
				this.Task_Item_Data[i].Task_Item_Id
			)
				this.Task_Item_search_Tasknew_ = this.Task_Item_Data[i];
		}
		for (var i = 0; i < this.Employer_Source_Data.length; i++) {
			if (this.Cas_Followup_.Employer_Source_Id == this.Employer_Source_Data[i].Employer_Source_Id)
				this.Employer_Source_ = this.Employer_Source_Data[i];
		}

		;
		for (var ij = 0; ij < this.Task_Status_Data.length;ij++) {
			if (
				this.Cas_Followup_.Task_Status ==
				this.Task_Status_Data[ij].Task_Status_Id
			)
				this.Task_Status_ = this.Task_Status_Data[ij];
		}
		;
		for (var ii = 0; ii < this.Interview_Status_Data.length; ii++) {
			if (this.Cas_Followup_.Interview_Status == this.Interview_Status_Data[ii].Interview_Status_Id)
				this.Interview_Status_ = this.Interview_Status_Data[ii];
		}

			;
		// for (var ik = 0; ik < this.Employer_Source_Data.length; ik++) {
		// 	if (this.Cas_Followup_.Employer_Source_Id == this.Employer_Source_Data[ik].Employer_Source_Id)
		// 		this.Employer_Source_ = this.Employer_Source_Data[ik];
		// }

        // for (var i = 0; i < this.Employer_Status_Data.length; i++) {
		// 	if (
		// 		this.Cas_Followup_.Employer_Status_Id ==
		// 		this.Employer_Status_Data[i].Employer_Status_Id
		// 	)
		// 		this.Employer_Status_ = this.Employer_Status_Data[i];
		// }
		
    // this.Entry_View =true;

    // this.Branch_=Branch_e;
    // if(Branch_e.Default_User_Id!=null)
    // {
    //     this.DefaultUsers_Temp.User_Details_Id =Branch_e.Default_User_Id;
    //     this.DefaultUsers_Temp.User_Details_Name = Branch_e.Default_User_Name;
    //     this.DefaultUsers_ = Object.assign({}, this.DefaultUsers_Temp); 
    // }
    // else{
    //     this.DefaultUsers_.User_Details_Id=0;
    //     this.DefaultUsers_.User_Details_Name="";
    // }


    // this.Cas_Followup_ = Object.assign({}, Branch_e);
    // this.Get_Branch_Department_Edit(this.Branch_.Branch_Id);

 





    }

	sanitizeUrl(url: string): SafeResourceUrl {

		return this.sanitizer.bypassSecurityTrustResourceUrl(url);
	  }
	View_Documents(Photo) {
		this.selectedPdfPreview=null
		var bs = environment.FilePath;
		var s = bs + Photo;
		
	this.pdfload=false


	this.selectedPdfPreview=this.sanitizeUrl(s)
	console.log('this.selectedPdfPreview: ', this.selectedPdfPreview);
	this.pdfload=true
	
	}
	handlePdfError() {
		// Handle the error, e.g., show a message or provide a fallback.
		console.error('Error loading PDF:', this.selectedPdfPreview);
		// You might want to set a default PDF or show a message to the user.
		this.selectedPdfPreview = null;
	  }


	display_Followup_UsersT(Users_T: Student_FollowUp) {
		if (Users_T) {
			return Users_T.UserName;
		}
	}
	display_DepartmentT(Department_t: Student_FollowUp) {
		if (Department_t) {
			return Department_t.Dept_Name;
		}
	}
	Close_Tasknewdetails() {
		this.main_View = true;
		this.Cas_FollowupTasknew_View = false;
		this.Clr_Tasknewcas_Followup();
		// this.Clr_cas_Followup();
	}



	InitLocation(type_ : number) {
		console.log('type_: ', type_);
		this.reverseGeocode(this.latitude, this.longitude,type_);

		// if (navigator.geolocation) {
		//   ;
		//   navigator.geolocation.getCurrentPosition(
		// 	(position) => {
		// 	  ;
		// 	  console.log(position);
		// 	  ;
		// 	  this.latitude = position.coords.latitude;
		// 	  this.longitude = position.coords.longitude;

		// 	  console.log(this.latitude);
		// 	  console.log(this.longitude);
	
		// 	  // Reverse geocode to get the location name (city and area)
		// 	  ;
		// 	  this.reverseGeocode(this.latitude, this.longitude,type_);
		// 	},
		// 	(error) => {
		// 	  this.error = 'Error getting location: ' + error.message;
		// 	}
		//   );
		// } else {
		//   this.error = 'Geolocation is not supported by your browser.';
		//   console.log(' this.error: ',  this.error);
		//   const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 	panelClass: "Dialogbox-Class",
		// 	data: { Message: "Please Enable Location to Continue", Type: "2" },
		// });
		// }
	  }

    reverseGeocode(latitude: number, longitude: number ,type_ : number) {
      ;
	  if (type_==1)
	  this.Save_CAS_NewTask_Followup_Click();
  else if (type_==2)
  this.Save_Cas_Followup_clk();
//       const nominatimApiUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
    
//       this.http.get(nominatimApiUrl).subscribe(

//         (data: any) => {
//         ;
//         if (data && data.address) {
//           this.city = data.address.city;
//           this.suburb = data.address.suburb;
//           this.county = data.address.county;
//           this.country = data.address.country;
//           this.state_district =data.address.state_district;
//           this.postcode=data.address.postcode;
//           this.country_code=data.address.country_code;
//           this.lat=this.latitude.toString();
//           this.long=this.longitude.toString();
        
//           if(this.city == undefined || this.city == "undefined" || this.city == null){
//             this.city = "";
//             }
//             if(this.suburb == undefined || this.suburb == "undefined" || this.suburb == null){
//             this.suburb = "";
//             }
//             if(this.county == undefined || this.county == "undefined" || this.county == null){
//             this.county = "";
//             }
//             if(this.state_district == undefined || this.state_district == "undefined" || this.state_district == null){
//             this.state_district = "";
//             }
//             if(this.country == undefined || this.country == "undefined" || this.country == null){
//             this.country = "";
//             }
//             if(this.postcode == undefined || this.postcode == "undefined" || this.postcode == null){
//             this.postcode = "";
//             }
//             if(this.country_code == undefined || this.country_code == "undefined" || this.country_code == null){
//             this.country_code = "";
//             }
//           console.log(this.county);
//   ;
//               this.uid = Number(localStorage.getItem("Login_User"));
// 			  if (type_==1)
// 			  	this.Save_CAS_NewTask_Followup_Click();
// 			  else if (type_==2)
// 			  this.Save_Cas_Followup_clk();

              // this.caid = Number(localStorage.getItem("Client_Accounts_Id"));
              console.log(this.uid);
    //           this.Student_Service_.Login_Location(this.uid,this.lat,this.long,this.city,this.suburb,this.county,this.state_district,this.country,
    //             this.postcode,this.country_code).subscribe((Rows) => {
    // // ;
    //                 console.log(Rows);
				
					

					
        //   localStorage.setItem("city", this.city);
        //   localStorage.setItem("suburb", this.suburb);
        //   localStorage.setItem("county", this.county);
        //   localStorage.setItem("country", this.country);
        //   localStorage.setItem("state_district", this.state_district);
        //   localStorage.setItem("postcode", this.postcode);
        //   localStorage.setItem("country_code", this.country_code);
      
        //   localStorage.setItem("latitude", this.latitude.toString());
        //   localStorage.setItem("longitude", this.longitude.toString());
    
//   });
         
  
  
    
    
    
    
        // } else {
        //   this.error = 'Location not found.';
        // }
        // },
        // (error) => {
        // this.error = 'Error fetching location data: ' + error.message;
        // }
    //   );
      }

	Save_CAS_NewTask_Followup() {

		this.InitLocation(1)

	}

	Save_CAS_NewTask_Followup_Click() {
		
debugger
		if (
			this.FollowUp_Branch_Task_ == undefined ||
			this.FollowUp_Branch_Task_ == null ||
			this.FollowUp_Branch_Task_.Branch_Id == undefined ||
			this.FollowUp_Branch_Task_.Branch_Id == 0
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Select Branch", Type: "3" },
			});
			return;
		}


		if (
			this.Job_Category_1_ == undefined ||
			this.Job_Category_1_ == null ||
			this.Job_Category_1_.Job_Category_Id == undefined ||
			this.Job_Category_1_.Job_Category_Id == 0
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Select job Sector ", Type: "3" },
			});
			return;
		}                                       


		// if (
		// 	this.FollowUp_Department_Task_ == undefined ||
		// 	this.FollowUp_Department_Task_ == null ||
		// 	this.FollowUp_Department_Task_.Department_Id == undefined ||
		// 	this.FollowUp_Department_Task_.Department_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Select Department", Type: "3" },
		// 	});
		// 	return;
		// }
		
		// if (
		// 	this.Followup_Users_Task_ == undefined ||
		// 	this.Followup_Users_Task_ == null ||
		// 	this.Followup_Users_Task_.User_Details_Id == undefined ||
		// 	this.Followup_Users_Task_.User_Details_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Select Staff", Type: "3" },
		// 	});
		// 	return;
		// }

		// if (
		// 	this.Task_Item_search_Tasknew_ == undefined ||
		// 	this.Task_Item_search_Tasknew_ == null ||
		// 	this.Task_Item_search_Tasknew_.Task_Item_Id == undefined ||
		// 	this.Task_Item_search_Tasknew_.Task_Item_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Select Task", Type: "3" },
		// 	});
		// 	return;
		// }
		if (
			this.Cas_Followup_.Task_Details == undefined ||
			this.Cas_Followup_.Task_Details == null ||
			this.Cas_Followup_.Task_Details == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Description", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Employer_Name == undefined ||
			this.Cas_Followup_.Employer_Name == null ||
			this.Cas_Followup_.Employer_Name == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Employer Name", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Mobile == undefined ||
			this.Cas_Followup_.Mobile == null ||
			this.Cas_Followup_.Mobile == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Mobile", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Land_Number == undefined ||
			this.Cas_Followup_.Land_Number == null ||
			this.Cas_Followup_.Land_Number == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Land Number", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Email_Id == undefined ||
			this.Cas_Followup_.Email_Id == null ||
			this.Cas_Followup_.Email_Id == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Email", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Contact_Person_Name == undefined ||
			this.Cas_Followup_.Contact_Person_Name == null ||
			this.Cas_Followup_.Contact_Person_Name == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Contact Person", Type: "3" },
			});
			return;
		}


		if (
			this.Cas_Followup_.Address == undefined ||
			this.Cas_Followup_.Address == null ||
			this.Cas_Followup_.Address == ""
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Enter Web Address", Type: "3" },
			});
			return;
		}


		// if (
		// 	this.Cas_Followup_.Country_Name == undefined ||
		// 	this.Cas_Followup_.Country_Name == null ||
		// 	this.Cas_Followup_.Country_Name == ""
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Enter Country", Type: "3" },
		// 	});
		// 	return;
		// }
		if(this.Job_Country_==1){ this.Cas_Followup_.Job_Country="United Kingdom"};
		if(this.Job_Country_==2){ this.Cas_Followup_.Job_Country="Ireland"}

		if (this.Job_Country_ == undefined || this.Job_Country_ == null|| this.Job_Country_ == 0) {
        
			const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Country', Type: "3" } });
			return;
		}

		// if (
		// 	this.Task_Status_ == undefined ||
		// 	this.Task_Status_ == null ||
		// 	this.Task_Status_.Task_Status_Id == undefined ||
		// 	this.Task_Status_.Task_Status_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Enter Task Status", Type: "3" },
		// 	});
		// 	return;
		// }


		// if (
		// 	this.Task_Status_ == undefined ||
		// 	this.Task_Status_ == null ||
		// 	this.Task_Status_.Task_Status_Id == undefined ||
		// 	this.Task_Status_.Task_Status_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Enter Task Status", Type: "3" },
		// 	});
		// 	return;
		// }
		// if (
		// 	this.Employer_Status_ == undefined ||
		// 	this.Employer_Status_ == null ||
		// 	this.Employer_Status_.Employer_Status_Id == undefined ||
		// 	this.Employer_Status_.Employer_Status_Id == 0
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Enter Employer Status", Type: "3" },
		// 	});
		// 	return;
		// }
		// if (
		// 	this.Cas_Followup_.Followup_Date == undefined ||
		// 	this.Cas_Followup_.Followup_Date == null 
		// ) {
		// 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
		// 		panelClass: "Dialogbox-Class",
		// 		data: { Message: "Choose Followup Date", Type: "3" },
		// 	});
		// 	return;
		// }	
		debugger
		this.Cas_Followup_.Student_Id = 0;
		this.Cas_Followup_.Department_Id = this.FollowUp_Department_Task_.Department_Id;
		this.Cas_Followup_.Department_Name = this.FollowUp_Department_Task_.Department_Name;
		this.Cas_Followup_.To_User = parseInt(this.Login_User);
		this.Cas_Followup_.To_User_Name = this.Login_User_Name;
		// let LoginUser=Number(localStorage.getItem('Login_User'))
		// console.log('LoginUser: ', LoginUser);
		// this.Cas_Followup_.To_User=LoginUser
		this.Cas_Followup_.Job_Category_Id = this.Job_Category_1_.Job_Category_Id;
		this.Cas_Followup_.Job_Category_Name = this.Job_Category_1_.Job_Category_Name;
		
		this.Cas_Followup_.Task_Status = this.Task_Status_.Task_Status_Id;
		this.Cas_Followup_.Status_Name = this.Task_Status_.Status_Name;

		this.Cas_Followup_.Task_Item_Id = this.Task_Item_search_Tasknew_.Task_Item_Id;
		this.Cas_Followup_.Branch_Id = this.FollowUp_Branch_Task_.Branch_Id;
		this.Cas_Followup_.Branch_Name = this.FollowUp_Branch_Task_.Branch_Name;
this.Cas_Followup_.Interview_Status = this.Interview_Status_.Interview_Status_Id;
		this.Cas_Followup_.Interview_Status_Name = this.Interview_Status_.Interview_Status_Name; // Include the name


this.Cas_Followup_.Employer_Status_Id = this.Task_Status_.Task_Status_Id;
this.Cas_Followup_.Employer_Status_Name = this.Task_Status_.Status_Name;

this.Cas_Followup_.Employer_Source=this.Employer_Source_.Employer_Source_Name;
this.Cas_Followup_.Employer_Source_Id=this.Employer_Source_.Employer_Source_Id;
		this.Cas_Followup_.By_User_Id = Number(this.Login_User);
		this.Cas_Followup_.By_User_Name = this.Login_User_Name;
		this.Cas_Followup_.City = this.city;
		this.Cas_Followup_.Suburb = this.suburb;
		this.Cas_Followup_.District = this.state_district;
		this.Cas_Followup_.County = this.county;
		this.Cas_Followup_.Followup_Date = this.New_Date(
			new Date(moment(this.Cas_Followup_.Followup_Date).format("YYYY-MM-DD"))
		);
		this.Cas_Followup_.Task_Group_Id = this.Task_Group_Id;
		if (this.Save_Call_Status == true) return;
		else this.Save_Call_Status = true;
		this.issLoading = true;
		debugger
		this.Student_Service_.Save_CAS_NewTask_Followup_Navbar_Employer(
			this.Cas_Followup_
		).subscribe(
			(Save_work_experience) => {
				debugger
				Save_work_experience = Save_work_experience[0];
				if (Number(Save_work_experience[0].Student_Task_Id_) > 0) {
					// if(this.Task_Group_Id==4)
					// {

					this.Save_Call_Status = false;
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Saved", Type: "false" },
					});
					// this.Get_WorkexperienceDetails(Save_work_experience[0].Student_Id_);
					this.Clr_Tasknewcas_Followup();
					this.Search_Lead_button();
					this.Close_Tasknewdetails();

					var notification_type_ = "Task";
					var message = {
						To_User: Save_work_experience[0].To_User_,
						Task_Count: Save_work_experience[0].Task_Count_,
						From_User_Name: Save_work_experience[0].From_User_Name_,
						Entry_Type: Save_work_experience[0].Entry_Type_,
						Notification_Type_Name: notification_type_,
					};
					this.socket.emit("new-message", message);
					//  }
				} else {
					const dialogRef = this.dialogBox.open(DialogBox_Component, {
						panelClass: "Dialogbox-Class",
						data: { Message: "Error Occured", Type: "2" },
					});
				}
				this.issLoading = false;
			},
			(Rows) => {
				this.issLoading = false;
				const dialogRef = this.dialogBox.open(DialogBox_Component, {
					panelClass: "Dialogbox-Class",
					data: { Message: Rows.error.error, Type: "2" },
				});
			}
		);
	}



	Search_Department_Typeahead_Tasknew(event: any) {
		var Value = "";
		if (event.target.value == "") Value = undefined;
		else Value = event.target.value;

		// if (
		// 	this.Followup_Department_Data_TN == undefined ||
		// 	this.Followup_Department_Data_TN.length == 0
		// ) {
		this.issLoading = true;

		this.Student_Service_.Search_Department_Typeahead_Tasknew(
			0
		).subscribe(
			(Rows) => {
				if (Rows != null) {
					this.Followup_Department_Data_TN = Rows[0];
					this.issLoading = false;
				}
			},
			(Rows) => {
				this.issLoading = false;
			}
		);
		// }
		//}
	}

	Dept_Change() {
		this.Followup_Users_tN = null;

		this.Followup_Users_Data_tN = [];

		// this.FollowUp_Status_.Department_Status_Id=0;
		//  this.Search_Substatus_Typeahead(this.FollowUp_Status_.Department_Status_Id);
	}


	Search_Branch_Department_Typeahead_Task(event: any,source:number) {
		
		var Value = "";
		if (event.target.value == "") Value = "";
		else Value = event.target.value.toLowerCase();

		if (
			this.FollowUp_Branch_Task_ == null ||
			this.FollowUp_Branch_Task_.Branch_Id == undefined
		) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Select Branch", Type: "3" },
			});
		} else {
			if (
				this.Followup_Department_Data == undefined ||
				this.Followup_Department_Data.length == 0
			) {
				// if (
				// 	this.Followup_Department_Data_Check == undefined ||
				// 	this.Followup_Department_Data_Check.length == 0
				// ) {
					this.issLoading = true;
					this.Student_Service_.Search_Branch_Department_Typeahead(
						this.FollowUp_Branch_Task_.Branch_Id,
						""
					).subscribe(
						(Rows) => {
							if (Rows != null) {
								// if(Rows.code!=undefined)
								// {
								//     const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.Code,Type:"false"}});
								// }
								this.Followup_Department_Data = Rows[0];
								this.Followup_Department_Data_Check = [];
								this.issLoading = false;
								if (source==1){
								for (var i = 0; i < this.Followup_Department_Data.length; i++) {
									if (
										this.Followup_Department_Data[i].Department_Name.toLowerCase().includes(
											Value
										)
									)
										this.Followup_Department_Data_Check.push(
											this.Followup_Department_Data[i]
										);
								}
								}
								else{
									this.Followup_Department_Data_Check =Rows[0];
								}
								
							}
						},
						(Rows) => {
							this.issLoading = false;
							const dialogRef = this.dialogBox.open(DialogBox_Component, {
								panelClass: "Dialogbox-Class",
								data: { Message: "Error Occured", Type: "2" },
							});
						}
					);
				// } else {
				// 	this.Followup_Department_Data = this.Followup_Department_Data_Check;
				// }
			}
			else {
				if(source==1){
					this.Followup_Department_Data_Check = [];
					for (var i = 0; i < this.Followup_Department_Data.length; i++) {
						if (
							this.Followup_Department_Data[i].Department_Name.toLowerCase().includes(Value)
						)
							this.Followup_Department_Data_Check.push(this.Followup_Department_Data[i]);
					}
				}else{
					this.Followup_Department_Data_Check = [];
					for (var i = 0; i < this.Followup_Department_Data.length; i++) {						
							this.Followup_Department_Data_Check.push(this.Followup_Department_Data[i]);
					}
				}
				
			}
		}
	}







	
	File_Change_std_Doc(event: Event) {
		const file = (event.target as HTMLInputElement).files;
		const fileSizeInMB = file[0].size / (1024 * 1024); // Convert bytes to megabytes

		if (fileSizeInMB > 5) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "File size exceeds 5 MB. Please select a smaller file.", Type: "3" },
			  });         // You can also reset the input if needed
		  // event.target.value = null;
		} else {
		this.file_b2b_changed=true
		const file = (event.target as HTMLInputElement).files;
		console.log('file: ', file);
		this.Cas_Followup_.Document_file = file;
		this.Cas_Followup_.Image_File_Name = file[0].name;
		}
	}
	Save_User_Document(){
		console.log('	this.file_b2b_changed: ', 	this.file_b2b_changed);
		console.log('this.Cas_Followup_: ', this.Cas_Followup_);
		
		if (!this.Cas_Followup_.Image_Description) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Description', Type: '3' } });
		} else if (!this.file_b2b_changed &&this.Cas_Followup_.Employer_Document_Id  ) {   //for edit if image is there then no need to upload to s3
			this.Save_Employer_Document();
		} else if (!this.Cas_Followup_.Document_file.length) {
			const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Document', Type: '3' } });
		} else {
			this.upload();
		}
		
	
	}
	upload(){
		this.issLoading=true
		console.log('   this.Cas_Followup_: ',    this.Cas_Followup_);
		
		  this.Student_Service_.uploadFile(  this.Cas_Followup_.Document_file.item(0)).then(
			res=>{
				console.log('  this.Cas_Followup_: ',   this.Cas_Followup_);
				  this.Cas_Followup_.Image_Path =res['key']
				console.log('res: ', res);
				this.Save_Employer_Document()
			}
		)
	
	}
	Save_Employer_Document(){
		this.issLoading=true
	
		console.log(' this.Cas_Followup_: ',  this.Cas_Followup_);
		this.Student_Service_.Save_Employer_Document(  this.Cas_Followup_).subscribe(Save_status => { 
			
			
			if(Save_status[0][0]['id'])
			
			this.Student_Service_.Get_Employer_Documents(this.Cas_Followup_.Student_Task_Id).subscribe(res=>{
				
				this.Cas_Followup_.uploaded_Document=res[0]
				this.issLoading=false
				this.file_b2b_changed=false
			this.clear_Document()
	
			})
		},err=>{
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Error Occured", Type: "2" },
			});
		}) 
	}

	Add_Document_Click_Employer(){
		// this.clear_Document()
		this.Student_Service_.Get_Employer_Documents(this.Cas_Followup_.Student_Task_Id).subscribe(res=>{
			console.log('res:@@@@@ ', res);
			this.Cas_Followup_.uploaded_Document=res[0]
			this.Add_Document_view=true;
	
		},err=>{
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
				panelClass: "Dialogbox-Class",
				data: { Message: "Error Occured", Type: "2" },
			});
		})
	}
	
	clear_Document(){
	
		this.Cas_Followup_.Employer_Document_Id =0;
		this.Cas_Followup_.Document_file = [];
							this.Cas_Followup_.Image_File_Name = '';
							this.Cas_Followup_.Image_Description = '';
	}
	
	Edit_Documents(doc)
	{
		this.Cas_Followup_.Employer_Document_Id=doc.Employer_Document_Id
	
		this.Cas_Followup_.Image_Description = doc.Image_Description;
		this.Cas_Followup_.Image_File_Name = doc.Image_File_Name;
	}	

	Download_Documents(doc){
		var bs = environment.FilePath;
		var s = bs + doc;
		window.open(s, "_blank");
	}

    Delete_Document(doc_Id){
		this.pdfload=false
		
		this.selectedPdfPreview=''
		this.issLoading=true
		console.log('doc_Id: ', doc_Id);
		
		this.Student_Service_.Delete_Employer_Documents(doc_Id).subscribe(res=>{
			console.log('res:@@@@@ ', res);
			
			if(res[0][0]['IsDelete']){
				this.issLoading=false
				this.clear_Document()
				this.Add_Document_Click_Employer()

				this.Cas_Followup_.uploaded_Document=res[1]
				this.Add_Document_view=true;
				this.pdfload=true
			}

		},err=>{
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
		})

	}



// 	Search_Department_User_Typeahead_Task(Department_Id) {
// 		this.issLoading = true;
// 
// 		this.Student_Service_.Search_Department_User_Typeahead_Task(
// 			this.FollowUp_Department_TN.Department
// 		).subscribe(
// 			(Rows) => {
// 				
// 				if (Rows != null) {
// 					this.Followup_Users_Data_tN = Rows[0];
// 					this.issLoading = false;
// 				}
// 			},
// 			(Rows) => {
// 				this.issLoading = false;
// 			}
// 		);
// 	}

// 	display_Followup_UsersT1(Users_T: Student_FollowUp) {
// 		if (Users_T) {
// 			return Users_T.UserName;
// 		}
// 	}




Search_Department_User_Typeahead_Task(event: any,source:number) {
	var Value = "";
	if (event.target.value == "") Value = "";
	else Value = event.target.value.toLowerCase();

	if (
		this.FollowUp_Branch_Task_ == null ||
		this.FollowUp_Branch_Task_.Branch_Id == undefined
	) {
		const dialogRef = this.dialogBox.open(DialogBox_Component, {
			panelClass: "Dialogbox-Class",
			data: { Message: "Select Branch", Type: "3" },
		});
	} else if (
		this.FollowUp_Department_Task_ == null ||
		this.FollowUp_Department_Task_.Department_Id == undefined
	) {
		const dialogRef = this.dialogBox.open(DialogBox_Component, {
			panelClass: "Dialogbox-Class",
			data: { Message: "Select Department", Type: "3" },
		});
	} 
		if (
			this.Followup_Users_Data_t == undefined 
			|| this.Followup_Users_Data_t == null || this.Followup_Users_Data_t.length == 0
		) {
			this.Student_Service_.Search_Department_User_Typeahead(
				this.FollowUp_Branch_Task_.Branch_Id,this.FollowUp_Department_Task_.Department_Id,""
			).subscribe(
				(Rows) => {
					if (Rows != null) {
						
						this.Followup_Users_Data_t = Rows[0];
						this.Followup_Users_Data_t_Filter = []
						if (source==1){
							for (var i = 0; i < this.Followup_Users_Data_t.length; i++) {
								if (
									this.Followup_Users_Data_t[i].User_Details_Name.toLowerCase().includes(
										Value
									)
								)
									this.Followup_Users_Data_t_Filter.push(
										this.Followup_Users_Data_t[i]
									);
							}
						}else{
							this.Followup_Users_Data_t_Filter= Rows[0];
						}
						
						this.issLoading = false;
					}
				},
				(Rows) => {
					this.issLoading = false;
					// const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
				}
			);
		// }
	}else {
		if(source==1){
			this.Followup_Users_Data_t_Filter = [];
			for (var i = 0; i < this.Followup_Users_Data_t.length; i++) {
				if (
					this.Followup_Users_Data_t[i].User_Details_Name.toLowerCase().includes(Value)
				)
					this.Followup_Users_Data_t_Filter.push(this.Followup_Users_Data_t[i]);
			}
		}else{
			this.Followup_Users_Data_t_Filter = [];
			for (var i = 0; i < this.Followup_Users_Data_t.length; i++) {					
					this.Followup_Users_Data_t_Filter.push(this.Followup_Users_Data_t[i]);
			}
		}
		
	}
}

Delete_Employer_Data(Student_Task_Id,index)
{

const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
// this.Search_Class();
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{

this.issLoading=true;

this.Student_Service_.Delete_Employer_Data(Student_Task_Id).subscribe(Delete_status => {
    
    
    
if(Delete_status[0][0].Student_Task_Id_>0){
this.Task_Data_Search.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_Task_Data();
}
else if(Number(Delete_status[0][0].Student_Task_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}

Job_Posting_Entry_View_Click(Page_Check)
{
	localStorage.setItem('Page_Check',Page_Check.toString());

    this.router.navigateByUrl('/Job_Posting');
}


Search_Job_Category_Typeahead(event: any) {
		
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Job_Category_1_Data=[]

    if (this.Job_Category_1_Data == undefined || this.Job_Category_1_Data.length == 0) {
        this.issLoading = true;

        this.Job_Category_Service_.Search_Job_Category_Typeahead(Value).subscribe(
            (Rows) => {
                
                if (Rows != null) {
                    this.Job_Category_1_Data = Rows[0];
                    this.Job_Category_1_Data_Filter = [];
                    for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
                        if (
                            this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value)
                        )
                            this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Job_Category_1_Data_Filter = [];
        for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
            if (this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value))
                this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
        }
    }
}

display_Job_Category(Job_Category_e: Job_Category) 
{
    if (Job_Category_e) {
        return Job_Category_e.Job_Category_Name;
    }
}

	
}
