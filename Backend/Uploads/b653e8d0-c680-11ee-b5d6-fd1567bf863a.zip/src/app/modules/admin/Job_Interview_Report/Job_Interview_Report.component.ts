import { Component, OnInit,Input,Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of as observableOf, merge } from 'rxjs';
import { Student_Service } from '../../../services/Student.Service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Student } from '../../../models/Student';
import { Branch } from '../../../models/Branch';
import { University_Service } from "../../../services/University.service";
import { User_Details } from '../../../models/User_Details';
import { Department } from '../../../models/Department';
import { Department_Status } from '../../../models/Department_Status';
import { Gender } from '../../../models/Gender';
import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogConfig} from '@angular/material';
import {FormControl} from '@angular/forms';
import { Max_Qualification_Service } from "app/services/Max_Qualification.Service";
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { Job_Posting } from 'app/models/Job_Posting';
import { Employer } from 'app/models/Employer';
import { Document } from 'app/models/Document';
import { Job } from "app/models/Job";
import { Job_Category } from "app/models/Job_Category";
import JSZip from 'jszip';
import { environment } from 'environments/environment';
import { HttpClient } from '@angular/common/http';
import { saveAs } from "file-saver";

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
parse: {
dateInput: 'DD/MM/YYYY',
},
display: {
dateInput: 'DD/MM/YYYY',monthYearLabel: 'MMM YYYY',dateA11yLabel: 'DD/MM/YYYY',monthYearA11yLabel: 'MMMM YYYY',
},
};

@Component({
selector: 'app-Job_Interview_Report',
templateUrl: './Job_Interview_Report.component.html',
styleUrls: ['./Job_Interview_Report.component.css'],
providers: [
{provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
],
})

export class Job_Interview_ReportComponent implements OnInit {
    Status_Search: Department_Status = new Department_Status();
    User_Search: User_Details = new User_Details();
    Search_Name = "";
    Department_Search: Department = new Department()
    Search_Branch: Branch = new Branch();
    Search_FromDate: Date = new Date();
    Search_ToDate: Date = new Date();
    Look_In_Date: Boolean = true;
    Document_Completed: Boolean = true;
    More_Search_Options: boolean = true;

    Department_Data: Department[]
    Users_Data: User_Details[]
    Branch_Data: Branch[]
    Status_Data: Department_Status[]
    Gender_Data: Gender[]
    Branch_Temp1: Branch = new Branch();
    Users_Temp: User_Details = new User_Details();
    Department_Temp: Department = new Department();
    Status_Temp: Department_Status = new Department_Status();
    missedfollowup_count: number = 1;
    followup_count: number = 1;


	Job_Category_1_Data: Job_Category[];
	Job_Category_1_Data_Filter: Job_Category[];
	Job_Category_1_: Job_Category = new Job_Category();
	Job_Category_1_Temp_: Job_Category = new Job_Category();



    Job_Data: Job[];
	Job_Filter: Job[];
	Job_: Job = new Job();
	Job_Temp_: Job = new Job();


    Total_Registrations:number=0;

    Job_Posting_: Job_Posting = new Job_Posting();
	Job_Posting_Temp: Job_Posting = new Job_Posting();
	Job_Posting_Data: Job_Posting[];
	Job_Posting_Data_Filter: Job_Posting[];
	Job_Posting_Search: Job_Posting = new Job_Posting();

    Employer_Tab_: Employer = new Employer();
	Employer_Temp: Employer = new Employer();
	Employer_Tab_Data: Employer[];
	Employer_Data_Filter: Employer[];
	Employer_Search: Employer = new Employer();

    Documents_: Document = new Document();
    Documents_Temp: Document = new Document();
	Documents_Data: Document[];


    Summary:boolean=false
    Summary_T:boolean=false
    Report:boolean=false

    Lead_Data: Student[]
    
    Student_Data_Search: Student[]
    Lead_: Student = new Student();
    Search_Div: boolean = false;
    
    array: any;
    color = 'primary';
    mode = 'indeterminate';
    value = 50;
    myInnerHeight: number;
    myTotalHeight:number;
    issLoading: boolean;

    Black: boolean = false;
    Red: boolean = false;
    pagePointer: number = 0;
    pageindex2: number = 0;
    pageindex: number = 0;
    Total_Rows: number = 0;
    Visa_Status_:number=0;

    issLoadingapi:boolean;
   zip = new JSZip();
   files = [
];
Actualfile_size:number;
Resume_Data:any;
selectedDataArray:any=[];
    
    isLoading = false;
    Search_By_: any;
    Registered_By_: any;
    year: any;
    month: any;
    day: any;
    date: any;
    Login_User: string = "0";
    Menu_Id: number = 51;

    Enquiry_Source_title = '';
    Enquiry_Source_type = 'BarChart';
    Type_PIe='PieChart'
    Branchwise_data = [  ];
    Data_Bar = [  ];
    Branchwise_columnNames = ['Source', 'Count'];
    Enquiry_Source_options = {
      is3D: true,
    };
    width = 550;
    height = 400; 
 



    RowCount: number = 0;
    RowCount2: number = 0;
    nextflag: number = -1;
    Page_Length_: number = 10;
    firstnum: number = 0;
    lastnum: number = 1;
    shownext: boolean = false;
    showprev: boolean = false;
    select_Resume:boolean=false;

    Black_Start: number = 1;
    Black_Stop: number = 0;
    Red_Start: number = 1;
    Red_Stop: number = 0;
    points25: boolean = false;
    Edit_Page_Permission: any;

    Graph:boolean=false
    Summary_Sub:boolean=false
    Export_Permission:any
    Export_View:boolean=false
    Total_Entries:number=0
    Total_Data:number=0;
    Permissions: any;
    View_Branch: string;
    Date_value: string;
    User_Id_Temp:number;
    ToDate:Date;
    FromDate:Date;
    Time_Change: number;
    ToDateString:string;
    FromDateString:string;
    TodayString:string;

    Count_Type:number=3;
    Department_Status_Type:number=0;
    Page_Check:number=0;
   

 
constructor(public Student_Service_:Student_Service,
    public Max_Qualification_Service_: Max_Qualification_Service,
    public University_Service_: University_Service,private _http: HttpClient, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) 
{   }
ngOnInit() 
{
  

    this.Login_User = localStorage.getItem("Login_User");
    this.Page_Check = Number(localStorage.getItem("Page_Check"))

    localStorage.setItem('Page_Check','0');
    this.Date_value = localStorage.getItem("Look_In_");
    this.User_Id_Temp= Number(localStorage.getItem("User_Search"));
    this.FromDate = new Date(localStorage.getItem('Search_FromDate'))
    this.ToDate = new Date(localStorage.getItem('Search_ToDate'));
    this.Time_Change = Number(localStorage.getItem("Time_Change"));
    this.Count_Type = Number(localStorage.getItem("Count_Type"));
    this.Department_Status_Type = Number(localStorage.getItem("Department_Status_Type"));

    if (this.Count_Type != 3) {
        localStorage.setItem("Count_Type", "3");
    }


    if (this.Department_Status_Type > 0) {
        localStorage.setItem("Department_Status_Type", "0");
    }

    console.log(this.FromDate,this.ToDate);
    debugger;
    this.ToDateString = this.ToDate.toString();
    this.FromDateString = this.FromDate.toString();
    this.TodayString = new Date().toString();


    if (this.ToDateString !== this.TodayString && this.FromDateString !== this.TodayString)
    {
        localStorage.setItem("Time_Change", "0");

    }


    if (this.User_Id_Temp > 0) {
        this.User_Id_Temp = Number(this.User_Id_Temp);
        localStorage.setItem("User_Search", "0");
    }

    if (this.Date_value == "false" ) {
        // this.Look_In_Date = Number(this.Date_value);
        localStorage.setItem("Look_In_", "true");

    }

  
    // this.array = Get_Page_Permission(this.Menu_Id);
    // this.Export_Permission= Get_Page_Permission(38);
    // if (this.array == undefined || this.array == null)
    // {
    //     localStorage.removeItem('token');
    //     this.router.navigateByUrl('/auth/login');
    // }
    // else 
    {
        this.Page_Load()
        // if (this.Export_Permission != undefined && this.Export_Permission != null)
        //     this.Export_View=this.Export_Permission.View
    
    }
}



Search_Job_Category_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Job_Category_1_Data == undefined || this.Job_Category_1_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Job_Category_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Job_Category_1_Data = Rows[0];
                    this.Job_Category_1_Data_Filter = [];
                    for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
                        if (
                            this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Job_Category_1_Data_Filter = [];
        for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
            if (
                this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value)
            )
                this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
        }
    }
}
display_Job_Category(Job_Category_e: Job_Category) {
    if (Job_Category_e) {
        return Job_Category_e.Job_Category_Name;
    }
}


Search_Employer_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Employer_Tab_Data == undefined || this.Employer_Tab_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Employer_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Employer_Tab_Data = Rows[0];
                    this.Employer_Data_Filter = [];
                    for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
                        if (
                            this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Employer_Data_Filter.push(this.Employer_Tab_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Employer_Data_Filter = [];
        for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
            if (
                this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(Value)
            )
                this.Employer_Data_Filter.push(this.Employer_Tab_Data[i]);
        }
    }
}
display_Employer_Tab(Experience_e: Employer) {
    if (Experience_e) {
        return Experience_e.Employer_Name;
    }
}


Search_Job_Typeahead(event: any) {


   




    
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Job_Data=[]
    if (this.Job_Data == undefined || this.Job_Data.length == 0) {
        this.issLoading = true;
debugger
        this.Max_Qualification_Service_.Search_Job_Typeahead_Temp(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Job_Data = Rows[0];
                    this.Job_Filter = [];
                    for (var i = 0; i < this.Job_Data.length; i++) {
                        if (
                            this.Job_Data[i].Job_Name.toLowerCase().includes(Value)
                        )
                            this.Job_Filter.push(this.Job_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Job_Filter = [];
        for (var i = 0; i < this.Job_Data.length; i++) {
            if (this.Job_Data[i].Job_Name.toLowerCase().includes(Value))
                this.Job_Filter.push(this.Job_Data[i]);
        }
    }
}

display_Job(Job_e: Job) 
{
    if (Job_e) {
        
        return Job_e.Job_Name;
    }
}



Page_Load()
{
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 280;

    this.Black_Stop = this.Page_Length_;
    this.Red_Stop = this.Page_Length_;
    this.Summary=false
    this.Report=true
    this.Graph=false;
    var my_date=new Date()
    this.Search_FromDate = new Date(my_date.getFullYear(), my_date.getMonth(), 1);
    this.Search_ToDate = this.New_Date(this.Search_ToDate);
    this.Search_By_=1;
    this.Registered_By_ = 1;
    this.select_Resume=false;
    // this.Get_Lead_Load_Data();
    this.Get_Menu_Status(51,this.Login_User);
    this.Get_Menu_Status(38,this.Login_User);
    this.Get_Lead_Load_Data_ByUser(this.Login_User);
    this.Get_Student_PageLoadData_Dropdowns();
    // this.Search_Student_Report();
    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 280;
    this.myTotalHeight=this.myTotalHeight - 40;
    this.myInnerHeight = this.myInnerHeight - 280;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Student_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    // if(Menu_id==17)

    if (Rows[0][0]==undefined)
    {
        if(Menu_id==51)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    // if (Rows[0][0]!=undefined)
    if (Rows[0][0].View >0) 
    {
        if(Menu_id==51)
        {
            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
     
        }
    }

    if(Menu_id==38)
        {
            this.Export_Permission=Rows[0][0];

            if (this.Export_Permission != undefined && this.Export_Permission != null)
            this.Export_View=this.Export_Permission.View;
            else
            this.Export_View=true;

        }

    
    // else
    // {
    //     localStorage.removeItem('token');
    //                 this.router.navigateByUrl('Home_Page'); 
    // }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}



New_Date(Date_)
{
    this.date = Date_;
    this.year = this.date.getFullYear();
    this.month = this.date.getMonth() + 1;
    if (this.month < 10)
    {
        this.month = "0" + this.month;
    }
    this.day = this.date.getDate().toString();
    if (Number.parseInt(this.day) < 10)
    {
        this.day = "0" + this.day;
    }
    this.date = this.year + "-" + this.month + "-" + this.day;
    return this.date;
}
trackByFn(index, item) 
{
return index;
}
Edit_Lead(Lead_Id, i) {
        localStorage.setItem('Lead_Id', Lead_Id);

        this.Edit_Page_Permission = Get_Page_Permission(1);
        if (this.Edit_Page_Permission == undefined) {
            const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'No permission to view', Type: "2" } });
        }
        else if (this.Edit_Page_Permission.View == true)
            this.router.navigateByUrl('/Leads');
        else {
            const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'No permission to view', Type: "2" } });
        }

    }
Search_Lead_button() 
{
    this.Black_Start =1;
    this.Black_Stop = this.Page_Length_;
    this.Red_Start = 1;
    this.Total_Rows=0;
    this.Red_Stop = this.Page_Length_;
    this.Search_Student_Report()
}
Search_Lead_button1() 
{
    this.Black_Start =1;
    this.Black_Stop = this.Page_Length_;
    this.Red_Start = 1;
    this.Total_Rows=0;
    this.Red_Stop = this.Page_Length_;
    this.Search_Registration_Report(this.User_Search.User_Details_Id);
}
Search_More_Options()
{
    if (this.More_Search_Options == true)
    this.More_Search_Options = false;
    else
    this.More_Search_Options = true;
}
Export()
{
        this.Student_Service_.exportExcel(this.Student_Data_Search,'Registration_Report')

}
Export_Summary()
{
        this.Student_Service_.exportExcel(this.Student_Data_Search,'Registration_Report_Summary')

}
View_Back()
{
    this.Summary=true
    this.Summary_Sub=true
    this.Report=false
    this.Search_Student_Report()
}
View_Details(User_Details_Id,ViewBranch)
{for (var i = 0; i < this.Users_Data.length; i++) {
    if (User_Details_Id== this.Users_Data[i].User_Details_Id)
    this.User_Search=this.Users_Data[i];
}

this.View_Branch   =ViewBranch;
this.Search_Registration_Report(User_Details_Id)
}
Search_Student_Report()
{
    
    this.Summary=false
    this.Summary_Sub=true
    this.Report=true
    this.Graph=false;
    this.Total_Registrations=0;
   
var value = 1, dept_id=0,User_Id=0,search_name_='0',look_In_Date_Value=0,branch_id=0;
    if(this.Search_By_!=undefined && this.Search_By_!=null)
    if (this.Search_By_ != undefined && this.Search_By_ != null && this.Search_By_ != '')
    value=this.Search_By_;

    if (this.Look_In_Date == true )
    look_In_Date_Value = 1;

    if (this.Search_Name != undefined && this.Search_Name != null && this.Search_Name != '')
    search_name_ = this.Search_Name;

    if (this.User_Search != undefined && this.User_Search!=null)
    if (this.User_Search.User_Details_Id != undefined && this.User_Search.User_Details_Id != null)
    User_Id = this.User_Search.User_Details_Id;

    if (this.Department_Search != undefined && this.Department_Search != null)
    if (this.Department_Search.Department_Id != undefined && this.Department_Search.Department_Id != null)
    dept_id = this.Department_Search.Department_Id;

    if (this.Search_Branch != undefined && this.Search_Branch != null)
    if (this.Search_Branch.Branch_Id != undefined && this.Search_Branch.Branch_Id != null)
    branch_id = this.Search_Branch.Branch_Id;


    this.issLoading = true;
    debugger;
    this.Student_Service_.Student_Registration_Summary(moment(this.Search_FromDate).format('YYYY-MM-DD'), moment(this.Search_ToDate).format('YYYY-MM-DD'), branch_id, look_In_Date_Value,this.Login_User,this.User_Id_Temp)
.subscribe(Rows => 
{
   debugger;
    this.issLoading = false;
    this.Student_Data_Search=Rows.returnvalue.Leads;
    this.Total_Entries=this.Student_Data_Search.length
    this.issLoading = false;
    this.Total_Registrations=0;
    var Branchwise_data_temp = Rows.returnvalue.Leads;
    for(var j=0;j<Branchwise_data_temp.length;j++){
        this.Total_Registrations=Number(this.Total_Registrations)+Number(Branchwise_data_temp[j].No_of_Registration)
    }
    this.issLoading = false;
    var result = [];
     this.Branchwise_columnNames=[];
    for (var i in Branchwise_data_temp)
    {
        result.push([Branchwise_data_temp[i].User, Branchwise_data_temp[i].No_of_Registration]);
       //this.Enquiry_Source_columnNames.push(Enquiry_Source_data_temp[i].Enquiry_Source_Name);
    }
        
    
    //var data_temp = new google.visualization.DataTable(result)
    this.Branchwise_columnNames.push('User_Details_Name')
    this.Branchwise_columnNames.push('Registration_Count')
    this.Branchwise_data = result;  
    this.Data_Bar=result;     
  debugger;
    if (this.Student_Data_Search.length ==0) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'No Data Found', Type: "3" } });
    }
    this.issLoading = false;
},
Rows => 
{   
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
    this.issLoading = false;
});
}

Search_Registration_Report(Count_Type)
{
    this.Summary=false
    this.Report=true
    this.select_Resume =false;
   // log(i)
   this.Total_Data=0;
var value = 1, dept_id=0,search_name_='0',look_In_Date_Value=0,branch_id=0,User_Id=0,Department_Status_Type=0,job_id=0,employer_id=0,visa_status=0,Document_Id=0;
    if(this.Search_By_!=undefined && this.Search_By_!=null)
    if (this.Search_By_ != undefined && this.Search_By_ != null && this.Search_By_ != '')
    value=this.Search_By_;

    if (this.Look_In_Date == true )
    look_In_Date_Value = 1;

    if (this.Search_Name != undefined && this.Search_Name != null && this.Search_Name != '')
    search_name_ = this.Search_Name;

    
    if (this.Employer_Tab_ != undefined && this.Employer_Tab_!=null)
    if (this.Employer_Tab_.Employer_Id != undefined && this.Employer_Tab_.Employer_Id != null)
    employer_id = this.Employer_Tab_.Employer_Id;

    // if (this.Documents_ != undefined && this.Documents_!=null)
    // if (this.Documents_.Document_Id != undefined && this.Documents_.Document_Id != null)
    // Document_Id = this.Documents_.Document_Id;

    // if (this.Visa_Status_ != undefined && this.Visa_Status_!=null)
    // visa_status = this.Visa_Status_;

    // if (this.Department_Status_Type != undefined && this.Department_Status_Type!=null)
    // Department_Status_Type = this.Department_Status_Type;

    if (this.Department_Search != undefined && this.Department_Search != null)
    if (this.Department_Search.Department_Id != undefined && this.Department_Search.Department_Id != null)
    dept_id = this.Department_Search.Department_Id;

    if (this.Job_Posting_ != undefined && this.Job_Posting_ != null)
    if (this.Job_Posting_.Job_Posting_Id != undefined && this.Job_Posting_.Job_Posting_Id != null)
    job_id = this.Job_Posting_.Job_Posting_Id;

debugger
    this.issLoading = true;
    
    this.Student_Service_.Search_job_interview_report(moment(this.Search_FromDate).format('YYYY-MM-DD'),
     moment(this.Search_ToDate).format('YYYY-MM-DD'), value, search_name_, job_id,employer_id,  
     look_In_Date_Value, this.Black_Start, this.Black_Stop, this.Login_User, this.Red_Start, this.Red_Stop,Count_Type)
.subscribe(Rows => 
{
    
    
    this.Total_Data=0;
    this.Student_Data_Search = Rows.returnvalue.Leads;
    var data1=Rows.returnvalue.Leads;
    this.Total_Data=data1.length;
    this.missedfollowup_count =0;
    this.followup_count=0;

    for (var i = 0; i < this.Student_Data_Search.length; i++) {
    this.Student_Data_Search[i].RowNo =i+1 + this.Total_Rows;
    if (this.Student_Data_Search[i].tp == 1)
    this.followup_count = this.followup_count + 1;
    if (this.Student_Data_Search[i].tp == 2)

    this.missedfollowup_count = this.missedfollowup_count + 1;
}

if ( this.Student_Data_Search.length>0)
this.Total_Rows= this.Total_Rows+this.Student_Data_Search.length;
this.issLoading = false;
if(this.Student_Data_Search.length==0)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
}
},
Rows => 
{   
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
    this.issLoading = false;
});
}

Get_Lead_Load_Data()
{
this.issLoading = true;
this.Student_Service_.Get_Lead_Load_Data().subscribe(Rows => {
   
    if (Rows != undefined)
    {
        this.issLoading = false;
        this.Department_Data = Rows.returnvalue.Department;
        this.Users_Data = Rows.returnvalue.Users;
        this.Branch_Data = Rows.returnvalue.Branch;
        this.Status_Data = Rows.returnvalue.Department_Status;

        this.Department_Temp.Department_Id = 0;
        this.Department_Temp.Department_Name = "All";
        this.Department_Data.unshift(Object.assign({}, this.Department_Temp));
        this.Department_Search = this.Department_Data[0];

        this.Users_Temp.User_Details_Id = 0;
        this.Users_Temp.User_Details_Name = "All";
        this.Users_Data.unshift(Object.assign({}, this.Users_Temp));
        this.User_Search = this.Users_Data[0];
        this.Branch_Temp1.Branch_Id = 0;

        this.Branch_Temp1.Branch_Name = "All";
        this.Branch_Data.unshift(this.Branch_Temp1);
        this.Search_Branch = this.Branch_Data[0];

        this.Status_Temp.Department_Status_Id = 0;
        this.Status_Temp.Department_Status_Name = "All";
        this.Status_Data.unshift(Object.assign({}, this.Status_Temp));
        this.Status_Search = this.Status_Data[0];
    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}


Get_Lead_Load_Data_ByUser(Login_User)
    {
        
        this.issLoading = true;
        this.Student_Service_.Get_Lead_Load_Data_ByUser(Login_User).subscribe(Rows => 
        
    {
     
    
      this.Department_Data = Rows[1].slice();
   this.Department_Temp.Department_Id = 0;
   this.Department_Temp.Department_Name = "All";
   this.Department_Data.unshift(this.Department_Temp);
   this.Department_Search = this.Department_Data[0];

   this.Users_Data = Rows[0].slice();
   this.Users_Temp.User_Details_Id = 0;
   this.Users_Temp.User_Details_Name = "All";
   this.Users_Data.unshift(this.Users_Temp);
   this.User_Search = this.Users_Data[0];
   
  
   this.Branch_Data = Rows[2].slice();
   this.Branch_Temp1.Branch_Id = 0;
   this.Branch_Temp1.Branch_Name = "All";
   this.Branch_Data.unshift(this.Branch_Temp1);
   this.Search_Branch = this.Branch_Data[0];

   this.Status_Data = Rows[5].slice();
   this.Status_Temp.Department_Status_Id = 0;
   this.Status_Temp.Department_Status_Name = "All";
   this.Status_Data.unshift(this.Status_Temp);
   this.Status_Search = this.Status_Data[0];
// debugger
//    if(this.Count_Type != 3 || this.Department_Status_Type>0)
//    {
//        this.Search_FromDate =this.FromDate;
//        this.Search_ToDate = this.ToDate;
//    }

//    else
//    {
//     var my_date=new Date()
//     this.Search_FromDate = this.New_Date(this.Search_FromDate);
//     this.Search_ToDate = this.New_Date(this.Search_ToDate);

//    }

//    if(this.Date_value=="false")
//    {
//      this.Look_In_Date=false
   
//    }
  

  
//    this.Search_FromDate = new Date(localStorage.getItem('Search_FromDate'));
//    this.Search_ToDate = new Date(localStorage.getItem('Search_ToDate'));

   if(this.User_Id_Temp!=0)
   {
    // debugger
    for (var i = 0; i < this.Users_Data.length; i++) {
        if (this.User_Id_Temp == this.Users_Data[i].User_Details_Id)
                this.User_Search = this.Users_Data[i];
                  }
                  
    }
   this.Search_Registration_Report(this.Count_Type);



},
Rows => { 
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });
}




Next_Click()
{
    if (this.Student_Data_Search.length == this.Page_Length_) 
    {
        this.Black_Start = this.Black_Start + this.Page_Length_;
        this.Black_Stop = this.Black_Stop + this.Page_Length_;
        if (this.missedfollowup_count > 0) {
        this.Red_Start = this.Red_Start + this.missedfollowup_count;
        this.Red_Stop = this.Red_Start + this.Page_Length_;
    }
this.nextflag = 1;
    if (this.Student_Data_Search.length > 0)
    {
        this.Search_Registration_Report(this.User_Search.User_Details_Id);
    }
}
}
previous_Click()
{
    if (this.Black_Start > 1) {
    {
        this.Black_Start = this.Black_Start - this.Page_Length_;
        this.Black_Stop = this.Black_Stop - this.Page_Length_;
    }
    if (this.missedfollowup_count > 0 || this.Red_Start > 1) 
    {
    this.Red_Start = this.Red_Start - this.Page_Length_;
    if (this.Red_Start <= 0)
    this.Red_Start = 1;
    this.Red_Stop = this.Red_Start + this.Page_Length_;
    }
    this.Total_Rows = this.Total_Rows - this.Student_Data_Search.length - this.Page_Length_;
    this.Search_Registration_Report(this.User_Search.User_Details_Id);
}
}   
Graph_View(){
    this.Summary_Sub=false
    this.Graph=true
}






Get_Student_PageLoadData_Dropdowns() {
    this.Student_Service_.Get_Student_PageLoadData_Dropdowns().subscribe(
        (Rows) => {

            // this.Job_Posting_Data = Rows[20].slice();
            // this.Job_Posting_Temp.Job_Posting_Id = 0;
            // this.Job_Posting_Temp.Details = "Select";
            // this.Job_Posting_Data.unshift(Object.assign({}, this.Job_Posting_Temp));
            // this.Job_Posting_ = this.Job_Posting_Data[0];


            // this.Employer_Tab_Data = Rows[24].slice();
            // this.Employer_Temp.Employer_Id = 0;
            // this.Employer_Temp.Employer_Name = "Select";
            // this.Employer_Tab_Data.unshift(Object.assign({}, this.Employer_Temp));
            // this.Employer_Tab_ = this.Employer_Tab_Data[0];

            this.Documents_Data = Rows[25].slice();
            this.Documents_Temp.Document_Id = 0;
            this.Documents_Temp.Document_Name = "Select";
            this.Documents_Data.unshift(Object.assign({}, this.Documents_Temp));
            this.Documents_ = this.Documents_Data[0];
debugger;

        },
        (Rows) => {
            const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
        }
    );
}

Resume_Click()
{
    
    for(var i=0;i<this.Student_Data_Search.length;i++)
    {
        if(this.select_Resume==false)
            this.Student_Data_Search[i].Check_Box=true;
        else
            this.Student_Data_Search[i].Check_Box=false;
    }

}

downloadZip(index_) {
    debugger

    var selectioncount=0;
        for(var i=0;i<this.Student_Data_Search.length;i++)
          if(this.Student_Data_Search[i].Check_Box==true)
            {
              selectioncount=1;
              break;
            }
    if(selectioncount==0)
    {
    const dialogRef = this.dialogBox.open    ( DialogBox_Component,
       {panelClass:'Dialogbox-Class',data:{Message:'Please select Student',Type:"3"}});
       return
    }
    // ;
    this.issLoadingapi=true;
  
    var ar=[];
    this.zip.forEach(function (relativePath, file){
      ar.push(relativePath)
       
    });
    for(var i=0;i<ar.length;i++)
        this.zip.remove(ar[i])
 
        var tempfile_size=0
        this.files=[];
        for(var i=0;i<this.Student_Data_Search.length;i++)
        {
          if(this.Student_Data_Search[i].Check_Box==true  && this.Student_Data_Search[i].Image !=null   )
          {
            debugger
            this.files.push({
                filename: environment.FilePath + this.Student_Data_Search[i].Image,
                Originalfilename: this.Student_Data_Search[i].Student_Name+ "_"+ this.Student_Data_Search[i].Document_Name+ "_" + i.toString(),
            });
        }
    }
    
    console.log('  this.files: ',   this.files);
 
 
 
           tempfile_size=120202;
        var value=((tempfile_size)/(1024))/(1024);
        this.Actualfile_size=Math.round(value);
      
            this.startDownload(0)
 
       
      }


      private startDownload(fileId)
  {
    

    debugger
    this.issLoading =true;

    if(this.files.length){

        if(this.files[fileId].filename!=''||this.files[fileId].filename!=undefined||this.files[fileId].filename!=null)
        this.loadSvgData(this.files[fileId].filename, fileId, this.saveAsZip);
    }else{
            this.issLoading =false;
        const dialogRef = this.dialogBox.open    ( DialogBox_Component,
            {panelClass:'Dialogbox-Class',data:{Message:' Selected Student has No document',Type:"3"}});
            return
    }
    this.issLoading =false;
  }
  private loadSvgData(url: string,fileId, callback: Function): void {
    debugger
    this._http
      .get(url, { responseType: 'arraybuffer' })
      .subscribe(x => 
        
        
        callback(x,fileId,url));
  }

saveAsZip = (content: Blob,fileid,Extenssion): void => 
  {  

    const fileName = this.files[fileid].filename.substring( this.files[fileid].filename.lastIndexOf('/') + 1);

    // Extract the file extension from the file name by considering the last dot
    const lastDotIndex = fileName.lastIndexOf('.');
    const fileExtension = lastDotIndex !== -1 ? fileName.substring(lastDotIndex + 1) : '';
    var extn=this.files[fileid].Originalfilename+'.'+fileExtension
    console.log('extn: ', extn);
    this.zip.file(extn, content);
    fileid++;
    
    if(fileid==this.files.length)
      this.download();
    else
      this.startDownload(fileid)

  };

save_zipfile(blob)
{
    console.log('blob: ', blob);
    debugger
    // this.company_name_zip =this.Company_Name_Public+'.zip'
  saveAs(blob, 'image.zip')
    // saveAs(blob, this.company_name_zip)
  this.issLoadingapi=false;
}

  private download() {
    // ;
    debugger
    this.issLoading=false;
    this.zip
      .generateAsync({ type: 'blob' })
      .then(blob => this.save_zipfile(blob));

  }




  Search_Employer_Typeahead_temp(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Employer_Tab_Data == undefined || this.Employer_Tab_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Employer_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Employer_Tab_Data = Rows[0];
                    this.Employer_Data_Filter = [];
                    for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
                        if (
                            this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Employer_Data_Filter.push(this.Employer_Tab_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Employer_Data_Filter = [];
        for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
            if (
                this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(Value)
            )
                this.Employer_Data_Filter.push(this.Employer_Tab_Data[i]);
        }
    }
}
display_Employer_Temp(Experience_e: Employer) {
    if (Experience_e) {
        return Experience_e.Employer_Name;
    }
}



}

