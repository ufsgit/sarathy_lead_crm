import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pending_Interview_ReportComponent} from './Pending_Interview_Report.component';
describe('Home_PageComponent', () => {
let component: Pending_Interview_ReportComponent;
let fixture: ComponentFixture<Pending_Interview_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Pending_Interview_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Pending_Interview_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

