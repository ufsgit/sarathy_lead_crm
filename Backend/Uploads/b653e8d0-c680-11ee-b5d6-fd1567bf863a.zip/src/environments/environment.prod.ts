export const environment = {
    production: true,

        // BasePath:'https://abcapi.ufstech.co.in/',
        // FilePath:'https://abcapi.ufstech.co.in/uploads/',
        // NotificationPath:'https://abcnotificationapi.ufstech.co.in/',     


        BasePath:'https://universalapi.ufstech.in/',
        FilePath:'https://ufsnabeelphotoalbum.s3.us-east-2.amazonaws.com/',
        NotificationPath:'https://universalnotificationapi.ufstech.in/',



};
