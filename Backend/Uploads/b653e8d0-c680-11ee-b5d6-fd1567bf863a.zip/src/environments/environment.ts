// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
	production: false,
	
	  BasePath: 'http://localhost:3509/',

    //   BasePath:'https://universalapi.ufstech.co.in/',
    // BasePath:'https://universalapi.ufstech.co.in/',
    FilePath:'https://ufsnabeelphotoalbum.s3.us-east-2.amazonaws.com/',



    // BasePath:'https://universalapi.ufstech.in/',
    // FilePath:'https://ufsnabeelphotoalbum.s3.us-east-2.amazonaws.com/',
     NotificationPath:'https://universalnotificationapi.ufstech.co.in/',

	
    // NotificationPath:'http://localhost:3510/',	


	// BasePath:'https://matglobarapi.mik.net.in/',
    //     FilePath:'https://matglobarapi.mik.net.in/uploads/',
    //     NotificationPath:'https://matglobarnotificationapi.mik.net.in/',  


	// BasePath:'https://cliftonapi.ufstech.co.in/',
    //     FilePath:'https://cliftonapi.ufstech.co.in/uploads/',
    //     NotificationPath:'https://cliftonnotificationapi.ufstech.co.in/',

	//  BasePath:'https://metx360api.trackbox.in/',
    //     FilePath:'https://metx360api.trackbox.in/uploads/',
    //     NotificationPath:'https://metx360notificationapi.trackbox.in/',



    // BasePath: 'https://universalapi.ufstech.in/',
    // FilePath:'https://universalapi.ufstech.in/uploads/',
    // NotificationPath:'https://universalnotificationapi.ufstech.in/',

    
    // BasePath:'https://universalapi.ufstech.co.in/',
    // FilePath:'https://ufsnabeelphotoalbum.s3.us-east-2.amazonaws.com/',
    // NotificationPath:'https://universalnotificationapi.ufstech.co.in/',

		
};
